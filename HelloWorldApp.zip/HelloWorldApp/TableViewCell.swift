//
//  TableViewCell.swift
//  HelloWorldApp
//
//  Created by yongho Yu on 2017. 2. 11..
//  Copyright © 2017년 eedler. All rights reserved.
//

import UIKit

class TableViewCell : UITableViewCell {
    @IBOutlet var lblNo: UILabel!
}
