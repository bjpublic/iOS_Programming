//
//  VC2.swift
//  HelloWorldApp
//
//  Created by yongho Yu on 2017. 2. 11..
//  Copyright © 2017년 eedler. All rights reserved.
//

import UIKit

class VC2: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func clickBtnBack(_ sender: Any) {
        /*if let vc = self.presentingViewController {
            vc.dismiss(animated: true, completion: nil)
        }*/
        if let navController = self.navigationController {
            navController.popViewController(animated: true)
        }
    }
    
}
