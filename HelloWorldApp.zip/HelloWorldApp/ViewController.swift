
import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var lblHello: UILabel!
    @IBOutlet var txtName: UITextField!
    @IBOutlet var tblList: UITableView!
    var arrNo: [Int] = []
    var stock: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.tblList.delegate = self
        self.tblList.dataSource = self
        
        for index in 1...10 {
            self.arrNo.append(index)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func changeHello(_ sender: Any) {
        //self.lblHello.text = "Hello Swift!"
        self.lblHello.text = self.txtName.text! + "님 안녕하세요!"
        /* if 조건문 예제 */
        /*
        let age = 30
        if age > 25 {
            self.lblHello.text = "Hello 형님!"
        } else {
            self.lblHello.text = "Hello 동생!"
        }*/
    }
    
    //tblList
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrNo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tblList.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        cell.lblNo.text = String(self.arrNo[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    @IBAction func clickBtnMove(_ sender: Any) {
        /*if let vc = self.storyboard?.instantiateViewController(withIdentifier: "VC2") {
            vc.modalTransitionStyle = UIModalTransitionStyle.coverVertical
            self.present(vc, animated: true, completion: nil)
        }*/
        if let uvc = self.storyboard?.instantiateViewController(withIdentifier: "VC2") {
            self.navigationController?.pushViewController(uvc, animated: true)
        }
    }
    
    @IBAction func goBack(segue:UIStoryboardSegue) {
        print("돌아가기 실행")
    }
}
