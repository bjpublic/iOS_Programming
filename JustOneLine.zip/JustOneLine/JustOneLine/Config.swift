//
//  Config.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 6..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit

class Config {
    static let sharedInstance = Config()
    
    var sort: Int
    var dateFormat: String
    
    var fontSizeMin: Int
    var fontSizeMax: Int
    
    var textAlignLeft: Bool
    var textAlignCenter: Bool
    var textAlignRight: Bool

    var backgroundContentClear: Bool
    var backgroundContentBlack: Bool
    
    var filterColorClear: Bool
    var filterColorRed: Bool
    var filterColorOrange: Bool
    var filterColorYellow: Bool
    var filterColorGreen: Bool
    var filterColorBlue: Bool
    var filterColorIndigo: Bool
    var filterColorViolet: Bool
    var filterColorWhite: Bool
    var filterColorBlack: Bool
    
    var activeBtnInShow: Bool
    
    let codeColor333: UIColor
    let codeColor444: UIColor
    let codeColor666: UIColor
    
    let codeColor1: UIColor
    let codeColor2: UIColor
    let codeColor3: UIColor
    let codeColor4: UIColor
    let codeColor5: UIColor
    
    let bcRed: UIColor
    let bcOrange: UIColor
    let bcYellow: UIColor
    let bcGreen: UIColor
    let bcBlue: UIColor
    let bcIndigo: UIColor
    let bcViolet: UIColor
    let bcWhite: UIColor
    let bcBlack: UIColor

    let fcClear: UIColor
    let fcRed: UIColor
    let fcOrange: UIColor
    let fcYellow: UIColor
    let fcGreen: UIColor
    let fcBlue: UIColor
    let fcIndigo: UIColor
    let fcViolet: UIColor
    let fcWhite: UIColor
    let fcBlack: UIColor
    
    fileprivate init() {

        self.sort = 1
        self.dateFormat = "YYYY-MM-dd"
        
        self.fontSizeMin = 16
        self.fontSizeMax = 24
        
        self.textAlignLeft = true
        self.textAlignCenter = true
        self.textAlignRight = true

        self.backgroundContentClear = true
        self.backgroundContentBlack = true
        
        self.filterColorClear = true
        self.filterColorRed = true
        self.filterColorOrange = true
        self.filterColorYellow = true
        self.filterColorGreen = true
        self.filterColorBlue = true
        self.filterColorIndigo = true
        self.filterColorViolet = true
        self.filterColorWhite = true
        self.filterColorBlack = true
        
        self.activeBtnInShow = true
        
        self.codeColor333 = UIColor(red: 33.0/255.0, green: 33.0/255.0, blue: 33.0/255.0, alpha: 1.0)
        self.codeColor444 = UIColor(red: 44.0/255.0, green: 44.0/255.0, blue: 44.0/255.0, alpha: 1.0)
        self.codeColor666 = UIColor(red: 66.0/255.0, green: 66.0/255.0, blue: 66.0/255.0, alpha: 1.0)
        
        self.codeColor1 = UIColor(red: 253.0/255.0, green: 253.0/255.0, blue: 253.0/255.0, alpha: 1.0)
        self.codeColor2 = UIColor(red: 219.0/255.0, green: 240.0/255.0, blue: 249.0/255.0, alpha: 1.0)
        self.codeColor3 = UIColor(red: 128.0/255.0, green: 186.0/255.0, blue: 195.0/255.0, alpha: 1.0)
        self.codeColor4 = UIColor(red: 22.0/255.0, green: 127.0/255.0, blue: 165.0/255.0, alpha: 1.0)
        self.codeColor5 = UIColor(red: 4.0/255.0, green: 39.0/255.0, blue: 49.0/255.0, alpha: 1.0)
        
        self.bcRed = UIColor(red: 255.0/255.0, green: 0/255.0, blue: 0/255.0, alpha: 0.7)
        self.bcOrange = UIColor(red: 255.0/255.0, green: 127.0/255.0, blue: 0/255.0, alpha: 0.7)
        self.bcYellow = UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 0/255.0, alpha: 0.7)
        self.bcGreen = UIColor(red: 0/255.0, green: 255.0/255.0, blue: 0/255.0, alpha: 0.7)
        self.bcBlue = UIColor(red: 0/255.0, green: 0/255.0, blue: 255.0/255.0, alpha: 0.7)
        self.bcIndigo = UIColor(red: 75.0/255.0, green: 0/255.0, blue: 130.0/255.0, alpha: 0.7)
        self.bcViolet = UIColor(red: 148.0/255.0, green: 0/255.0, blue: 211.0/255.0, alpha: 0.7)
        self.bcWhite = UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 0.7)
        self.bcBlack = UIColor(red: 0, green: 0, blue: 0, alpha: 0.7)
        
        self.fcClear = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.0)
        self.fcRed = UIColor(red: 150.0/255.0, green: 60.0/255.0, blue: 43.0/255.0, alpha: 0.27)
        self.fcOrange = UIColor(red: 179.0/255.0, green: 123.0/255.0, blue: 44.0/255.0, alpha: 0.27)
        self.fcYellow = UIColor(red: 179.0/255.0, green: 179.0/255.0, blue: 44.0/255.0, alpha: 0.27)
        self.fcGreen = UIColor(red: 69.0/255.0, green: 129.0/255.0, blue: 49.0/255.0, alpha: 0.27)
        self.fcBlue = UIColor(red: 0/255.0, green: 103.0/255.0, blue: 163.0/255.0, alpha: 0.27)
        self.fcIndigo = UIColor(red: 75.0/255.0, green: 0/255.0, blue: 130.0/255.0, alpha: 0.22)
        self.fcViolet = UIColor(red: 148.0/255.0, green: 0/255.0, blue: 211.0/255.0, alpha: 0.22)
        self.fcWhite = UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 0.22)
        self.fcBlack = UIColor(red: 0, green: 0, blue: 0, alpha: 0.26)
    }
}
