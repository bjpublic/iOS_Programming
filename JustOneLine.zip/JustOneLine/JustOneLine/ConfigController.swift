//
//  ConfigController.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 19..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit

class ConfigController {
    static let sharedInstance = ConfigController()
    let defaults = UserDefaults.standard
    let config = Config.sharedInstance
    
    fileprivate init() {
        if self.defaults.object(forKey: "sort") != nil {
            self.config.sort = self.defaults.integer(forKey: "sort")
        }
        
        if let value = self.defaults.string(forKey: "dateFormat") {
            self.config.dateFormat = value
        }
        
        if self.defaults.object(forKey: "fontSizeMin") != nil {
            self.config.fontSizeMin = self.defaults.integer(forKey: "fontSizeMin")
        }

        if self.defaults.object(forKey: "fontSizeMax") != nil {
            self.config.fontSizeMax = self.defaults.integer(forKey: "fontSizeMax")
        }
        
        if self.defaults.object(forKey: "textAlignLeft") != nil {
            self.config.textAlignLeft = self.defaults.bool(forKey: "textAlignLeft")
        }

        if self.defaults.object(forKey: "textAlignCenter") != nil {
            self.config.textAlignCenter = self.defaults.bool(forKey: "textAlignCenter")
        }

        if self.defaults.object(forKey: "textAlignRight") != nil {
            self.config.textAlignRight = self.defaults.bool(forKey: "textAlignRight")
        }

        if self.defaults.object(forKey: "backgroundContentClear") != nil {
            self.config.backgroundContentClear = self.defaults.bool(forKey: "backgroundContentClear")
        }
        
        if self.defaults.object(forKey: "backgroundContentBlack") != nil {
            self.config.backgroundContentBlack = self.defaults.bool(forKey: "backgroundContentBlack")
        }
        
        if self.defaults.object(forKey: "filterColorClear") != nil {
            self.config.filterColorClear = self.defaults.bool(forKey: "filterColorClear")
        }
        
        if self.defaults.object(forKey: "filterColorRed") != nil {
            self.config.filterColorRed = self.defaults.bool(forKey: "filterColorRed")
        }
        
        if self.defaults.object(forKey: "filterColorOrange") != nil {
            self.config.filterColorOrange = self.defaults.bool(forKey: "filterColorOrange")
        }
        
        if self.defaults.object(forKey: "filterColorYellow") != nil {
            self.config.filterColorYellow = self.defaults.bool(forKey: "filterColorYellow")
        }
        
        if self.defaults.object(forKey: "filterColorGreen") != nil {
            self.config.filterColorGreen = self.defaults.bool(forKey: "filterColorGreen")
        }
        
        if self.defaults.object(forKey: "filterColorBlue") != nil {
            self.config.filterColorBlue = self.defaults.bool(forKey: "filterColorBlue")
        }
        
        if self.defaults.object(forKey: "filterColorIndigo") != nil {
            self.config.filterColorIndigo = self.defaults.bool(forKey: "filterColorIndigo")
        }
        
        if self.defaults.object(forKey: "filterColorViolet") != nil {
            self.config.filterColorViolet = self.defaults.bool(forKey: "filterColorViolet")
        }
        
        if self.defaults.object(forKey: "filterColorWhite") != nil {
            self.config.filterColorWhite = self.defaults.bool(forKey: "filterColorWhite")
        }
        
        if self.defaults.object(forKey: "filterColorBlack") != nil {
            self.config.filterColorBlack = self.defaults.bool(forKey: "filterColorBlack")
        }

    }
    
    func updateConfig() {
        self.defaults.set(self.config.sort, forKey: "sort")
        self.defaults.set(self.config.dateFormat, forKey: "dateFormat")
        
        self.defaults.set(self.config.fontSizeMin, forKey: "fontSizeMin")
        self.defaults.set(self.config.fontSizeMax, forKey: "fontSizeMax")
        
        self.defaults.set(self.config.textAlignLeft, forKey: "textAlignLeft")
        self.defaults.set(self.config.textAlignCenter, forKey: "textAlignCenter")
        self.defaults.set(self.config.textAlignRight, forKey: "textAlignRight")
        
        self.defaults.set(self.config.backgroundContentClear, forKey: "backgroundContentClear")
        self.defaults.set(self.config.backgroundContentBlack, forKey: "backgroundContentBlack")

        self.defaults.set(self.config.filterColorClear, forKey: "filterColorClear")
        self.defaults.set(self.config.filterColorRed, forKey: "filterColorRed")
        self.defaults.set(self.config.filterColorOrange, forKey: "filterColorOrange")
        self.defaults.set(self.config.filterColorYellow, forKey: "filterColorYellow")
        self.defaults.set(self.config.filterColorGreen, forKey: "filterColorGreen")
        self.defaults.set(self.config.filterColorBlue, forKey: "filterColorBlue")
        self.defaults.set(self.config.filterColorIndigo, forKey: "filterColorIndigo")
        self.defaults.set(self.config.filterColorViolet, forKey: "filterColorViolet")
        self.defaults.set(self.config.filterColorWhite, forKey: "filterColorWhite")
        self.defaults.set(self.config.filterColorBlack, forKey: "filterColorBlack")
    }

    func setActiveBtnInShow(_ bool: Bool) {
        self.config.activeBtnInShow = bool
    }
    
    func getDateTimeFormat(_ dateTime: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = self.config.dateFormat + " HH:mm"
        return "\(formatter.string(from: dateTime))"
    }
    
    func getDateFormat(_ dateTime: Date ) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = self.config.dateFormat
        return "\(formatter.string(from: dateTime))"
    }
    
    func getTimeFormat(_ dateTime: Date ) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return "\(formatter.string(from: dateTime))"
    }
}
