//
//  CustomLabel.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 4. 28..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit

class CustomLabel: UILabel {
    override func drawText(in rect: CGRect) {
        super.drawText(in: UIEdgeInsetsInsetRect(rect, UIEdgeInsets(top: 5, left: 15, bottom: 5, right: 5)))
    }
}
