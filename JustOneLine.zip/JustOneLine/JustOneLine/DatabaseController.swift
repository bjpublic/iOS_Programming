//
//  DatabaseController.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 30..
//  Copyright © 2016년 eedler. All rights reserved.
//

import Foundation

class DatabaseController {
    static let sharedInstance = DatabaseController()
    let dbPath: String
    let fileName: String = "JustOneLine.sqlite"
    
    fileprivate init() {
        let filemgr = FileManager.default
        let dirPaths = filemgr.urls(for: .documentDirectory, in: .userDomainMask)
        self.dbPath = dirPaths[0].appendingPathComponent(self.fileName).path
        
        if !filemgr.fileExists(atPath: self.dbPath) {
            self.initDB()
        }
    }
    
    func initDB() {
        let db = FMDatabase(path: self.dbPath)
        if db == nil {
            NSLog("DB Create Error: \(db?.lastErrorMessage())")
        }
        
        if (db?.open())! {
            let sql_lines = "CREATE TABLE IF NOT EXISTS Lines "
            + " (idx INTEGER PRIMARY KEY AUTOINCREMENT "
            + " ,content TEXT "
            + " ,subContent TEXT "
            + " ,createdAt TEXT) "
            if !(db?.executeStatements(sql_lines))! {
                NSLog("DB Execute Error: \(db?.lastErrorMessage())")
            }

            db?.close()
        } else {
            NSLog("DB Open Error: \(db?.lastErrorMessage())")
        }
    }
    
    func select(_ query: String, arg: [AnyObject]) -> FMResultSet {
        let db = FMDatabase(path: self.dbPath)
        var result = FMResultSet()
        
        if db == nil {
            NSLog("DB Connect Error: \(db?.lastErrorMessage())")
        }
        
        if (db?.open())! {
            result = (db?.executeQuery(query, withArgumentsIn: arg))!
            db?.close()
        } else {
            NSLog("DB Open Error: \(db?.lastErrorMessage())")
        }
        return result
    }
    
    func execute(_ query: String) -> Bool {
        let db = FMDatabase(path: self.dbPath)
        var result = false
        
        if db == nil {
            NSLog("DB Connect Error: \(db?.lastErrorMessage())")
        }
        
        if (db?.open())! {
            result = (db?.executeUpdate(query, withArgumentsIn: nil))!
            db?.close()
        } else {
            NSLog("DB Open Error: \(db?.lastErrorMessage())")
        }
        return result
    }
    
    func insert(_ query: String) -> Int {
        let db = FMDatabase(path: self.dbPath)
        var result = 0
        
        if db == nil {
            NSLog("DB Connect Error: \(db?.lastErrorMessage())")
        }
        
        if (db?.open())! {
            if (db?.executeUpdate(query, withArgumentsIn: nil))! {
                let results:FMResultSet? = db?.executeQuery("SELECT last_insert_rowid() AS insert_idx ", withArgumentsIn: nil)
                if results?.next() == true {
                    result = Int((results?.string(forColumn: "insert_idx"))!)!
                }
            }
            db?.close()
        } else {
            NSLog("DB Open Error: \(db?.lastErrorMessage())")
        }
        return result
    }
}
