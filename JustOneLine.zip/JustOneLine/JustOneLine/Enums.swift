//
//  Enums.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 8..
//  Copyright © 2016년 eedler. All rights reserved.
//

enum Direction {
    case top
    case bottom
}

enum WriteType {
    case insert
    case update
}

enum BtnConfigForDetail {
    case sort
    case dateFormat
    case fontSize
    case textAlign
    case contentsBackground
    case filterColor
}
