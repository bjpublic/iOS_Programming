//
//  IDocument.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 26..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit

class IDocument {
    static let sharedInstance = IDocument()
    
    struct DocumentsDirectory {
        static let localDocumentsURL: URL? = FileManager.default.urls(for: FileManager.SearchPathDirectory.documentDirectory, in: .userDomainMask).last! as URL
        static var iCloudDocumentsURL: URL? = FileManager.default.url(forUbiquityContainerIdentifier: nil)
    }

    func isCloudEnabled() -> Bool {
        DocumentsDirectory.iCloudDocumentsURL = FileManager.default.url(forUbiquityContainerIdentifier: nil)
        if DocumentsDirectory.iCloudDocumentsURL != nil { return true }
        else { return false }
    }
    
    func backupDocument() {
        let databaseController = DatabaseController.sharedInstance
        let fileName = databaseController.fileName
        
        let fileManager = FileManager.default
        let enumerator = fileManager.enumerator(atPath: DocumentsDirectory.localDocumentsURL!.path)
        
        while let file = enumerator?.nextObject() as? String {
            if file == fileName {
                let ubiquityURL = DocumentsDirectory.iCloudDocumentsURL!.appendingPathComponent(file)
                let localURL = DocumentsDirectory.localDocumentsURL!.appendingPathComponent(file)
                //NSLog("\(localURL)")
                if fileManager.fileExists(atPath: ubiquityURL.path) {
                    do {
                        try fileManager.removeItem(at: ubiquityURL)
                    } catch let error as NSError {
                        NSLog("Failed to remove file to iCloud dir : \(error.localizedDescription)")
                    }
                } else {
                    //NSLog("Not Exists: \(ubiquityURL.path!)")
                }
                do {
                    try fileManager.copyItem(at: localURL, to: ubiquityURL)
                } catch let error as NSError {
                    NSLog("Failed to copy file to iCloud dir : \(error.localizedDescription)")
                }
            }
        }
    }
    
    func restoreDocument() {
        let databaseController = DatabaseController.sharedInstance
        let fileName = databaseController.fileName

        let fileManager = FileManager.default
        let enumerator = fileManager.enumerator(atPath: DocumentsDirectory.iCloudDocumentsURL!.path)
        
        while let file = enumerator?.nextObject() as? String {
            if file == fileName {
                let ubiquityURL = DocumentsDirectory.iCloudDocumentsURL!.appendingPathComponent(file)
                let localURL = DocumentsDirectory.localDocumentsURL!.appendingPathComponent(file)
                
                if fileManager.fileExists(atPath: localURL.path) {
                    do {
                        try fileManager.removeItem(at: localURL)
                    } catch let error as NSError {
                        NSLog("Failed to remove file to local dir : \(error.localizedDescription)")
                    }
                } else {
                    //NSLog("Not Exists: \(localURL.path!)")
                }
                do {
                    try fileManager.copyItem(at: ubiquityURL, to: localURL)
                } catch let error as NSError {
                    NSLog("Failed to copy file to local dir : \(error.localizedDescription)")
                }
            }
        }
    }
}
