//
//  RandomLine.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 6..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit

class LimitedRandom {
    static let sharedInstance = LimitedRandom()
    
    var images = Array<UIImage>()
    var filterColors = Array<UIColor>()
    var fontSizes = Array<CGFloat>()
    var txtAligns = Array<NSTextAlignment>()
    var vContentBgColors = Array<UIColor>()
    
    let config = Config.sharedInstance
    
    fileprivate init() {
        // image list
        let fm = FileManager.default
        let path = Bundle.main.resourcePath!
        let items = try! fm.contentsOfDirectory(atPath: path)
        for item in items {
            if item.hasPrefix("bg0") && item.hasSuffix(".jpg") {
                self.images.append(UIImage(named: item)!)
            }
        }

        self.setFontSizes()
        self.setFilterColors()
        self.setTextAligns()
        self.setVContentBgColors()
    }
    
    func setFontSizes() {
        self.fontSizes = Array<CGFloat>()
        for index in Int32(self.config.fontSizeMin)...Int32(self.config.fontSizeMax) {
            self.fontSizes.append(CGFloat(index))
        }
    }

    func setFilterColors() {
        self.filterColors = Array<UIColor>()
        if config.filterColorClear == true {
            self.filterColors.append(self.config.fcClear)
        }
        if config.filterColorRed == true {
            self.filterColors.append(self.config.fcRed)
        }
        if config.filterColorOrange == true {
            self.filterColors.append(self.config.fcOrange)
        }
        if config.filterColorYellow == true {
            self.filterColors.append(self.config.fcYellow)
        }
        if config.filterColorGreen == true {
            self.filterColors.append(self.config.fcGreen)
        }
        if config.filterColorBlue == true {
            self.filterColors.append(self.config.fcBlue)
        }
        if config.filterColorIndigo == true {
            self.filterColors.append(self.config.fcIndigo)
        }
        if config.filterColorViolet == true {
            self.filterColors.append(self.config.fcViolet)
        }
        if config.filterColorWhite == true {
            self.filterColors.append(self.config.fcWhite)
        }
        if config.filterColorBlack == true {
            self.filterColors.append(self.config.fcBlack)
        }
    }
    
    func setTextAligns() {
        self.txtAligns = Array<NSTextAlignment>()
        if config.textAlignLeft == true {
            self.txtAligns.append(NSTextAlignment.left)
        }
        if config.textAlignCenter == true {
            self.txtAligns.append(NSTextAlignment.center)
        }
        if config.textAlignRight == true {
            self.txtAligns.append(NSTextAlignment.right)
        }
    }

    func setVContentBgColors() {
        self.vContentBgColors = Array<UIColor>()
        if config.backgroundContentClear == true {
            self.vContentBgColors.append(UIColor.clear)
        }
        if config.backgroundContentBlack == true {
            self.vContentBgColors.append(UIColor(red: 0, green: 0, blue: 0, alpha: 0.4))
        }
    }
    
    func getRandomImage() -> UIImage {
        let randomNo = Int(arc4random_uniform(UInt32(self.images.count)));
        return self.images[randomNo]
    }
    
    func getRandomFilterColor() -> UIColor {
        let randomNo = Int(arc4random_uniform(UInt32(self.filterColors.count)));
        return self.filterColors[randomNo]
    }
    
    func getRandomFontSize() -> CGFloat {
        let randomNo = Int(arc4random_uniform(UInt32(self.fontSizes.count)));
        return self.fontSizes[randomNo]
    }
    
    func getRandomAlign() -> NSTextAlignment {
        let randomNo = Int(arc4random_uniform(UInt32(self.txtAligns.count)));
        return self.txtAligns[randomNo]
    }
    
    func getRandomVContentBgColor() -> UIColor {
        let randomNo = Int(arc4random_uniform(UInt32(self.vContentBgColors.count)));
        return self.vContentBgColors[randomNo]
    }
    
    func getTimeColor() -> UIColor {
        var customColor: UIColor = UIColor()
        let floatHour = self.getCGFloatFromTime("HH")
        let floatMinute = self.getCGFloatFromTime("mm")
        let floatSecond = self.getCGFloatFromTime("ss")
        customColor = UIColor(red: floatHour/255.0, green: floatMinute/255.0, blue: floatSecond/255.0, alpha: 1.0)
        return customColor
    }
    
    func getCGFloatFromTime(_ format:String) -> CGFloat {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        let timeHex = formatter.string(from: Date())
        return CGFloat(UInt8(strtoul(timeHex, nil, 16)))
    }
    
    func getRandomConstContent(_ contentHeight: CGFloat) -> CGFloat {
        let screenHeight = UIScreen.main.bounds.height
        let marginHeight = Int32(screenHeight - contentHeight)
        var constHeight: CGFloat = 0
        
        if marginHeight <= 20 {
            constHeight = 20
        } else {
            constHeight = CGFloat( arc4random_uniform( UInt32(marginHeight-20) ) + 20);
        }
        return constHeight
    }
}
