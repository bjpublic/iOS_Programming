//
//  Line.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 4. 28..
//  Copyright © 2016년 eedler. All rights reserved.
//

import Foundation

class Line {
    var content: String
    var subContent: String
    var createdAt: Date
    
    init() {
        self.content = ""
        self.subContent = ""
        self.createdAt = Date()
    }
}
