//
//  LineCell.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 4. 28..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit

class LineCell: UITableViewCell {
    @IBOutlet var imgView: UIImageView!
    @IBOutlet var lblContent: UILabel!
    @IBOutlet var lblCreatedAt: UILabel!
}