//
//  LineShow.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 12..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit
import CoreData

class LineContainer {
    var line: Line
    var idx: Int
    var imgBg: UIImage
    var filterColor: UIColor
    var fontSize: CGFloat
    var fontAlign: NSTextAlignment
    var vContentBackgroundColor: UIColor
    var constTopVContent: CGFloat

    init() {
        let ltdRnd = LimitedRandom.sharedInstance

        self.line = Line()
        self.idx = 0
        self.imgBg = ltdRnd.getRandomImage()
        self.filterColor = ltdRnd.getRandomFilterColor()
        self.fontSize = ltdRnd.getRandomFontSize()
        self.fontAlign = ltdRnd.getRandomAlign()
        self.vContentBackgroundColor = ltdRnd.getRandomVContentBgColor()
        self.constTopVContent = 0
    }
    
    init(idx: Int, line: Line) {
        let ltdRnd = LimitedRandom.sharedInstance
        
        self.line = line
        self.idx = idx
        self.imgBg = ltdRnd.getRandomImage()
        self.filterColor = ltdRnd.getRandomFilterColor()
        self.fontSize = ltdRnd.getRandomFontSize()
        self.fontAlign = ltdRnd.getRandomAlign()
        self.vContentBackgroundColor = ltdRnd.getRandomVContentBgColor()
        self.constTopVContent = 0
    }
}
