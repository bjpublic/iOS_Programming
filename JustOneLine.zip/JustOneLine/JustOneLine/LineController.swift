//
//  LineModel.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 6..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit

class LineController {
    static let sharedInstance = LineController()
    let config = Config.sharedInstance
    
    var lineContainers = Array<LineContainer>()
    
    fileprivate init() {
        self.setAllData()
    }

    func initData() {
        self.lineContainers = Array<LineContainer>()
    }
    
    func setAllData() {
        self.setSelectedData()
    }

    func searchData(_ searchKey: String) {
        if searchKey == "" {
            self.initData()
        } else {
            self.setSelectedData(searchKey)
        }
    }
    
    func setSelectedData(_ searchKey: String = "") {
        let fmdb = DatabaseController.sharedInstance
        let db = FMDatabase(path: fmdb.dbPath)
        
        var sql = ""
        var paramDictionary = [AnyObject]()
        if searchKey == "" {
            sql = self.getSelectQuery()
        } else {
            sql = self.getSelectQuery(searchKey: true)
            let searchKeyForWhere = "%" + searchKey + "%"
            paramDictionary = [AnyObject]()
            paramDictionary.append(searchKeyForWhere as AnyObject)
            paramDictionary.append(searchKeyForWhere as AnyObject)
        }
        
        if (db?.open())! {
            let results: FMResultSet = db!.executeQuery(sql, withArgumentsIn: paramDictionary)
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            
            self.lineContainers = Array<LineContainer>()
            while results.next() == true {
                let line = Line()
                line.content = results.string(forColumn: "content")
                line.subContent = results.string(forColumn: "subContent")
                line.createdAt = dateFormatter.date(from: results.string(forColumn: "createdAt"))!
                
                let lineContainer = LineContainer(idx: Int(results.string(forColumn: "idx"))!, line: line)
                self.lineContainers.append(lineContainer)
            }
        }
        db?.close()
    }

    func getSelectQuery(searchKey: Bool = false) -> String {
        var sql = " SELECT "
            + "     idx, "
            + "     content, "
            + "     subContent, "
            + "     createdAt "
            + " FROM "
            + "     Lines "
        
        let sqlWhere = " WHERE "
            + "     content LIKE ? "
            + "     OR subContent LIKE ? "
        
        if searchKey == true {
            sql = sql + sqlWhere
        }
        
        var sqlOrder = ""
        if self.config.sort == 1 {
            sqlOrder = " ORDER BY idx ASC "
        } else {
            sqlOrder = " ORDER BY idx DESC "
        }
        
        sql = sql + sqlOrder
        return sql
    }
    
    func insertLine(_ line: Line) -> Int {
        let newLine = Line()
        newLine.content = line.content
        newLine.subContent = line.subContent
        newLine.createdAt = Date()
        
        var newIdx: Int = 0
        
        let fmdb = DatabaseController.sharedInstance
        let db = FMDatabase(path: fmdb.dbPath)
        
        let sql = ""
            + " INSERT INTO Lines ( "
            + "     content "
            + "     ,subContent "
            + "     ,createdAt "
            + " ) VALUES ( "
            + "     ? "
            + "     ,? "
            + "     ,? "
            + " ) "

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        var paramDictionary = [AnyObject]()
        paramDictionary.append(newLine.content as AnyObject)
        paramDictionary.append(newLine.subContent as AnyObject)
        paramDictionary.append(dateFormatter.string(from: newLine.createdAt as Date) as AnyObject)
        
        if (db?.open())! {
            if (db?.executeUpdate(sql, withArgumentsIn: paramDictionary))! {
                let results:FMResultSet = db!.executeQuery("SELECT last_insert_rowid() AS insert_idx ", withArgumentsIn: nil)
                if results.next() == true {
                    newIdx = Int(results.int(forColumn: "insert_idx"))
                    let lineContainer = LineContainer(idx: Int(newIdx), line: newLine)
                    
                    if self.config.sort == 1 {
                        self.lineContainers.append(lineContainer)
                    } else {
                        self.lineContainers.insert(lineContainer, at: 0)
                    }
                }
            }
        }
        db?.close()
        
        return newIdx
    }
    
    func updateLine(_ lineContainer: LineContainer) {
        let newLine = Line()
        newLine.content = lineContainer.line.content
        newLine.subContent = lineContainer.line.subContent
        newLine.createdAt = Date()
        
        let fmdb = DatabaseController.sharedInstance
        let db = FMDatabase(path: fmdb.dbPath)
        
        let sql = " UPDATE Lines SET "
        + "     content = ? "
        + "     ,subContent = ? "
        + " WHERE "
        + "     idx = ? "

        var paramDictionary = [AnyObject]()
        paramDictionary.append(newLine.content as AnyObject)
        paramDictionary.append(newLine.subContent as AnyObject)
        paramDictionary.append(lineContainer.idx as AnyObject)
        
        if (db?.open())! {
            if (db?.executeUpdate(sql, withArgumentsIn: paramDictionary))! {
                let idxNo = self.getIndex(lineContainer.idx)
                self.lineContainers[idxNo].line.content = newLine.content
                self.lineContainers[idxNo].line.subContent = newLine.subContent
            }
        }
        db?.close()
    }
    
    func deleteLineByIdx(_ lineContainer: LineContainer) {
        let fmdb = DatabaseController.sharedInstance
        let db = FMDatabase(path: fmdb.dbPath)
        
        let sql = " DELETE FROM Lines WHERE idx = ? "
        
        var paramDictionary = [AnyObject]()
        paramDictionary.append(lineContainer.idx as AnyObject)
        
        if (db?.open())! {
            if (db?.executeUpdate(sql, withArgumentsIn: paramDictionary))! {
                let idxNo = self.getIndex(lineContainer.idx)
                self.lineContainers.remove(at: idxNo)
            }
        }
        db?.close()
    }
    
    func getIndex(_ idx: Int) -> Int {
        var index: Int = 0
        for lineContainer in self.lineContainers {
            if lineContainer.idx == idx {
                return index
            }
            index = index + 1
        }
        return -1
    }
}
