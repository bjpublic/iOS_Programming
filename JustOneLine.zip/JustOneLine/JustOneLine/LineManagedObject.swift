//
//  LineManagedObject.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 6..
//  Copyright © 2016년 eedler. All rights reserved.
//

import Foundation
import CoreData

class LineManagedObject: NSManagedObject {
    @NSManaged var content: String
    @NSManaged var subContent: String
    @NSManaged var createdAt: Date
}
