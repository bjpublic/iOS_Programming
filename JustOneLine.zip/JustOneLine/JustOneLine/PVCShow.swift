//
//  PVCShow.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 5..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit

class PVCShow: UIPageViewController, UIPageViewControllerDataSource {
    
    var idx: Int = 0
    let lineController = LineController.sharedInstance
    var vCs = Array<VCShow>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.dataSource = self
        self.setData()
        self.show()
    }
    
    func setData() {
        self.vCs = Array<VCShow>()
        for lineContainer in self.lineController.lineContainers {
            self.vCs.append(self.getVCShow(lineContainer))
        }
    }

    func show() {
        let index = self.lineController.getIndex(self.idx)
        setViewControllers([self.vCs[index]], direction: .forward, animated: true, completion: nil)
    }
    
    func getVCShow(_ lineController: LineContainer) -> VCShow {
        let uvc = self.storyboard?.instantiateViewController(withIdentifier: "VCShow") as! VCShow
        uvc.lineContainer = lineController
        return uvc
    }

    func refresh() {
        self.setData()
        if self.lineController.lineContainers.count == 0 {
            self.closePVCShow()
            return
        }
    }
    
    func moveBack() {
        let index = self.lineController.getIndex(self.idx)
        if index > 0 {
            setViewControllers([self.vCs[index-1]], direction: .reverse, animated: true, completion: nil)
        }
    }
    
    func moveNext() {
        let index = self.lineController.getIndex(self.idx)
        if index + 1 <= self.lineController.lineContainers.count - 1 {
            setViewControllers([self.vCs[index+1]], direction: .forward, animated: true, completion: nil)
        }
    }

    func moveToIndex(_ index: Int, animated: Bool = true) {
        if index >= 0 && index <= self.vCs.count-1 {
            var drt : UIPageViewControllerNavigationDirection
            let nowIndex = self.lineController.getIndex(self.idx)
            if nowIndex > index {
                drt = .reverse
            } else {
                drt = .forward
            }
            setViewControllers([self.vCs[index]], direction: drt, animated: animated, completion: nil)
        }
    }
    
    func closePVCShow() {
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = self.vCs.index(of: viewController as! VCShow) else {
            return nil
        }
        let previousIndex = viewControllerIndex - 1
        
        guard previousIndex >= 0 else {
            return nil
        }
        
        guard self.vCs.count > previousIndex else {
            return nil
        }
        return self.vCs[previousIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = self.vCs.index(of: viewController as! VCShow) else {
            return nil
        }
        let nextIndex = viewControllerIndex + 1
        let count = self.vCs.count
        
        guard count != nextIndex else {
            return nil
        }
        
        guard count > nextIndex else {
            return nil
        }
        return self.vCs[nextIndex]
    }

}
