//
//  Reachability.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 27..
//  Copyright © 2016년 eedler. All rights reserved.
//

import Foundation

class Reachability {
    static func isConnectedToNetwork() -> Bool {
        let url = URL(string: "https://google.com/")
        let data: Data? = try? Data(contentsOf: url!)
        if data == nil {
            return false
        } else {
            return true
        }
    }
}
