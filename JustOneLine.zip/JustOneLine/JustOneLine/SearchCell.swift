//
//  SearchCell.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 23..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit

class SearchCell: UITableViewCell {

    @IBOutlet var lblContent: UILabel!
    @IBOutlet var lblCreatedAt: UILabel!
}