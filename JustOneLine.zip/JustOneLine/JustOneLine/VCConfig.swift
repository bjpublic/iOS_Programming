//
//  VCConfig.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 16..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit

class VCConfig: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet var btnClose: UIButton!
    
    @IBOutlet var btnSort: UIButton!
    @IBOutlet var pkSort: UIPickerView!
    @IBOutlet var constPkSortHeight: NSLayoutConstraint!
    
    @IBOutlet var btnDateFormat: UIButton!
    @IBOutlet var pkDateFormat: UIPickerView!
    @IBOutlet var constPkDateFormatHeight: NSLayoutConstraint!
    
    @IBOutlet var btnFontSize: UIButton!
    @IBOutlet var pkFontSize: UIPickerView!
    @IBOutlet var constPkFontSizeHeight: NSLayoutConstraint!
    
    @IBOutlet var btnTextAlign: UIButton!
    @IBOutlet var vTextAlign: UIView!
    @IBOutlet var constBtnTextAlignHeight: NSLayoutConstraint!
    @IBOutlet var btnTextAlignLeft: UIButton!
    @IBOutlet var btnTextAlignCenter: UIButton!
    @IBOutlet var btnTextAlignRight: UIButton!

    @IBOutlet var btnContentsBackground: UIButton!
    @IBOutlet var vContentsBackground: UIView!
    @IBOutlet var constBtnContentsBackgroundHeight: NSLayoutConstraint!
    @IBOutlet var btnContentsBackgroundClear: UIButton!
    @IBOutlet var btnContentsBackgroundBlack: UIButton!
    
    @IBOutlet var btnFilterColor: UIButton!
    @IBOutlet var vFilterColorBtn: UIView!
    @IBOutlet var constBtnFilterColorClearHeight: NSLayoutConstraint!

    @IBOutlet var btnFilterColorClear: UIButton!
    @IBOutlet var btnFilterColorRed: UIButton!
    @IBOutlet var btnFilterColorOrange: UIButton!
    @IBOutlet var btnFilterColorYellow: UIButton!
    @IBOutlet var btnFilterColorGreen: UIButton!
    @IBOutlet var btnFilterColorBlue: UIButton!
    @IBOutlet var btnFilterColorIndigo: UIButton!
    @IBOutlet var btnFilterColorViolet: UIButton!
    @IBOutlet var btnFilterColorWhite: UIButton!
    @IBOutlet var btnFilterColorBlack: UIButton!
    
    @IBOutlet var btnBackup: UIButton!
    @IBOutlet var btnRestore: UIButton!
    
    var pkSortDataSource = [String]()
    var pkDateFormatDataSource = [String]()
    var pkFontSizeDataSource = [[String]]()
    
    var togglePkSort: Bool = false
    var heightPkSort: CGFloat = 0
    var togglePkDateFormat: Bool = false
    var heightPkDateFormat: CGFloat = 0
    var togglePkFontSize: Bool = false
    var heightPkFontSize: CGFloat = 0
    var toggleVTextAlign: Bool = false
    var heightBtnTextAlign: CGFloat = 0
    var toggleVContentsBackground: Bool = false
    var heightBtnContentsBackground: CGFloat = 0
    var toggleVFilterColor: Bool = false
    var heightBtnFilterColor: CGFloat = 0

    let ltdRnd = LimitedRandom.sharedInstance
    let configController = ConfigController.sharedInstance
    let lineController = LineController.sharedInstance

    var firstSortValue: Int = 0
    
    var actInd: UIActivityIndicatorView = UIActivityIndicatorView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.pkSort.dataSource = self;
        self.pkSort.delegate = self;
        self.pkDateFormat.dataSource = self;
        self.pkDateFormat.delegate = self;
        self.pkFontSize.dataSource = self;
        self.pkFontSize.delegate = self;
        
        self.setInit()
        self.setBtn()
        
        self.setBtnTitleOpenPkSort()
        self.setPkSort()
        self.setBtnTitleOpenPkDateFormat()
        self.setPkDateFormat()
        self.setBtnTitleOpenPkFontSize()
        self.setPkFontSize()
        
        self.setBtnTitleOpenTextAlign()
        self.setBtnTitleTextAlign()
        
        self.setBtnTitleOpenContentsBackground()
        self.setBtnTitleContentsBackground()
        
        self.setBtnTitleFilterColor()
        
        self.firstSortValue = self.configController.config.sort
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
 
    func setInit() {
        self.pkSortDataSource.append(NSLocalizedString("Most Recent At Top", comment: "Most Recent At Top"))
        self.pkSortDataSource.append(NSLocalizedString("Most Recent At Bottom", comment: "Most Recent At Bottom"))
        
        self.pkDateFormatDataSource.append("YYYY-MM-DD")
        self.pkDateFormatDataSource.append("YYYY.MM.DD")
        self.pkDateFormatDataSource.append("DD/MM/YYYY")
        self.pkDateFormatDataSource.append("DD.MM.YYYY")
        self.pkDateFormatDataSource.append("MM/DD/YYYY")
        
        self.pkFontSizeDataSource.append([])
        self.pkFontSizeDataSource.append([])
        for index in 10...30 {
            self.pkFontSizeDataSource[0].append(String(index))
            self.pkFontSizeDataSource[1].append(String(index))
        }
            
        self.heightPkSort = self.constPkSortHeight.constant
        self.constPkSortHeight.constant = 0
        self.heightPkDateFormat = self.constPkDateFormatHeight.constant
        self.constPkDateFormatHeight.constant = 0
        self.heightPkFontSize = self.constPkFontSizeHeight.constant
        self.constPkFontSizeHeight.constant = 0
        self.heightBtnTextAlign = self.constBtnTextAlignHeight.constant
        self.constBtnTextAlignHeight.constant = 0
        self.vTextAlign.isHidden = true
        self.heightBtnContentsBackground = self.constBtnContentsBackgroundHeight.constant
        self.constBtnContentsBackgroundHeight.constant = 0
        self.vContentsBackground.isHidden = true
        self.heightBtnFilterColor = self.constBtnFilterColorClearHeight.constant
        self.constBtnFilterColorClearHeight.constant = 0
        self.vFilterColorBtn.isHidden = true
    }

    func setBtn() {
        let titleColor = self.configController.config.codeColor444
        
        self.btnClose.setTitle("\u{f00d}",for: UIControlState())

        self.btnFilterColorClear.setTitleColor(self.configController.config.bcBlack, for: UIControlState())
        self.btnFilterColorRed.setTitleColor(self.configController.config.bcRed, for: UIControlState())
        self.btnFilterColorOrange.setTitleColor(self.configController.config.bcOrange, for: UIControlState())
        self.btnFilterColorYellow.setTitleColor(self.configController.config.bcYellow, for: UIControlState())
        self.btnFilterColorGreen.setTitleColor(self.configController.config.bcGreen, for: UIControlState())
        self.btnFilterColorBlue.setTitleColor(self.configController.config.bcBlue, for: UIControlState())
        self.btnFilterColorIndigo.setTitleColor(self.configController.config.bcIndigo, for: UIControlState())
        self.btnFilterColorViolet.setTitleColor(self.configController.config.bcViolet, for: UIControlState())
        self.btnFilterColorWhite.setTitleColor(self.configController.config.bcBlack, for: UIControlState())
        self.btnFilterColorBlack.setTitleColor(self.configController.config.bcBlack, for: UIControlState())

        self.btnClose.setTitleColor(titleColor, for: UIControlState())
        self.btnSort.setTitleColor(titleColor, for: UIControlState())
        self.btnDateFormat.setTitleColor(titleColor, for: UIControlState())
        self.btnFontSize.setTitleColor(titleColor, for: UIControlState())
        self.btnTextAlign.setTitleColor(titleColor, for: UIControlState())
        self.btnTextAlignLeft.setTitleColor(titleColor, for: UIControlState())
        self.btnTextAlignCenter.setTitleColor(titleColor, for: UIControlState())
        self.btnTextAlignRight.setTitleColor(titleColor, for: UIControlState())
        self.btnContentsBackground.setTitleColor(titleColor, for: UIControlState())
        self.btnContentsBackgroundClear.setTitleColor(titleColor, for: UIControlState())
        self.btnContentsBackgroundBlack.setTitleColor(self.configController.config.bcBlack, for: UIControlState())
        self.btnBackup.setTitleColor(titleColor, for: UIControlState())
        self.btnRestore.setTitleColor(titleColor, for: UIControlState())
        self.btnFilterColor.setTitleColor(titleColor, for: UIControlState())

        let borderColor = self.configController.config.codeColor444.cgColor
        self.btnClose.layer.borderColor = borderColor
        self.btnSort.layer.borderColor = borderColor
        self.btnDateFormat.layer.borderColor = borderColor
        self.btnFontSize.layer.borderColor = borderColor
        self.btnTextAlign.layer.borderColor = borderColor
        self.btnTextAlignLeft.layer.borderColor = borderColor
        self.btnTextAlignCenter.layer.borderColor = borderColor
        self.btnTextAlignRight.layer.borderColor = borderColor
        self.btnContentsBackground.layer.borderColor =  borderColor
        self.btnContentsBackgroundClear.layer.borderColor =  borderColor
        self.btnContentsBackgroundBlack.layer.borderColor =  borderColor
        self.btnFilterColor.layer.borderColor = borderColor
        self.btnBackup.layer.borderColor = borderColor
        self.btnRestore.layer.borderColor = borderColor
        
        let borderWidth: CGFloat = 1.0
        self.btnClose.layer.borderWidth = borderWidth
        self.btnSort.layer.borderWidth = borderWidth
        self.btnDateFormat.layer.borderWidth = borderWidth
        self.btnFontSize.layer.borderWidth = borderWidth
        self.btnTextAlign.layer.borderWidth = borderWidth
        self.btnTextAlignLeft.layer.borderWidth = borderWidth
        self.btnTextAlignCenter.layer.borderWidth = borderWidth
        self.btnTextAlignRight.layer.borderWidth = borderWidth
        self.btnContentsBackground.layer.borderWidth = borderWidth
        self.btnContentsBackgroundClear.layer.borderWidth = borderWidth
        self.btnContentsBackgroundBlack.layer.borderWidth = borderWidth
        self.btnBackup.layer.borderWidth = borderWidth
        self.btnRestore.layer.borderWidth = borderWidth
        self.btnFilterColor.layer.borderWidth = borderWidth
        
        let pkBorderColor = self.configController.config.codeColor444.cgColor
        self.pkSort.layer.borderColor = pkBorderColor
        self.pkDateFormat.layer.borderColor = pkBorderColor
        self.pkFontSize.layer.borderColor = pkBorderColor
    }
    
    func setBtnTitleOpenPkSort() {
        var title: String = ""
        if configController.config.sort == 0 {
            title = NSLocalizedString("Top", comment: "Top")
        } else {
            title = NSLocalizedString("Bottom", comment: "Bottom")
        }
        self.btnSort.setTitle(title, for: UIControlState())
    }

    func setPkSort() {
        let sort = self.configController.config.sort
        self.pkSort.selectRow(Int(sort), inComponent: 0, animated: false)
    }
    
    func setBtnTitleOpenPkDateFormat() {
        let dateFormat = self.configController.config.dateFormat
        let title = dateFormat.replacingOccurrences(of: "dd", with: "DD")
        self.btnDateFormat.setTitle(title, for: UIControlState())
    }
    
    func setPkDateFormat() {
        let dateFormat: String = self.configController.config.dateFormat
        let newDateFormat = dateFormat.replacingOccurrences(of: "dd", with: "DD")
        for index in 0..<self.pkDateFormatDataSource.count {
            if newDateFormat == self.pkDateFormatDataSource[index] {
                self.pkDateFormat.selectRow(index, inComponent: 0, animated: false)
            }
        }
    }
    
    func setBtnTitleOpenPkFontSize() {
        var title: String = ""
        title = NSLocalizedString("Min", comment: "Min") + " " + String(Int(self.configController.config.fontSizeMin))
        title = title + ", " + NSLocalizedString("Max", comment: "Max") + " " + String(Int(self.configController.config.fontSizeMax))
        self.btnFontSize.setTitle(title, for: UIControlState())
    }
    
    func setPkFontSize() {
        let fontSizeMin: String = String(Int(self.configController.config.fontSizeMin))
        let fontSizeMax: String = String(Int(self.configController.config.fontSizeMax))
        
        for index in 0..<self.pkFontSizeDataSource[0].count {
            if fontSizeMin == self.pkFontSizeDataSource[0][index] {
                self.pkFontSize.selectRow(index, inComponent: 0, animated: false)
            }
            if fontSizeMax == self.pkFontSizeDataSource[1][index] {
                self.pkFontSize.selectRow(index, inComponent: 1, animated: false)
            }
        }
    }
    
    @IBAction func clickBtnClose(_ sender: UIButton) {
        self.ltdRnd.setFontSizes()
        self.ltdRnd.setTextAligns()
        self.ltdRnd.setVContentBgColors()
        self.ltdRnd.setFilterColors()
        self.lineController.setAllData()
        let presentV = self.presentingViewController as! ViewController
        presentV.refreshData()
        if self.firstSortValue != self.configController.config.sort {
            if configController.config.sort == 0 {
                presentV.moveScroll(Direction.top)
            } else {
                presentV.moveScroll(Direction.bottom)
            }
        }
        presentV.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func clickOpenPkSort(_ sender: UIButton) {
        if self.togglePkSort == false {
            self.togglePkDateFormat = false
            self.closeDetailSelector(BtnConfigForDetail.dateFormat)
            self.togglePkFontSize = false
            self.closeDetailSelector(BtnConfigForDetail.fontSize)
            self.toggleVTextAlign = false
            self.closeDetailSelector(BtnConfigForDetail.textAlign)
            self.toggleVContentsBackground = false
            self.closeDetailSelector(BtnConfigForDetail.contentsBackground)
            self.toggleVFilterColor = false
            self.closeDetailSelector(BtnConfigForDetail.filterColor)
            self.togglePkSort = true
            self.openDetailSelector(BtnConfigForDetail.sort)
        } else {
            self.togglePkSort = false
            self.closeDetailSelector(BtnConfigForDetail.sort)
        }
    }
    
    @IBAction func clickOpenPkDateFormat(_ sender: UIButton) {
        if self.togglePkDateFormat == false {
            self.togglePkSort = false
            self.closeDetailSelector(BtnConfigForDetail.sort)
            self.togglePkFontSize = false
            self.closeDetailSelector(BtnConfigForDetail.fontSize)
            self.toggleVTextAlign = false
            self.closeDetailSelector(BtnConfigForDetail.textAlign)
            self.toggleVContentsBackground = false
            self.closeDetailSelector(BtnConfigForDetail.contentsBackground)
            self.toggleVFilterColor = false
            self.closeDetailSelector(BtnConfigForDetail.filterColor)
            self.togglePkDateFormat = true
            self.openDetailSelector(BtnConfigForDetail.dateFormat)
        } else {
            self.togglePkDateFormat = false
            self.closeDetailSelector(BtnConfigForDetail.dateFormat)
        }
    }
    
    @IBAction func clickOpenPkFontSize(_ sender: UIButton) {
        if self.togglePkFontSize == false {
            self.togglePkSort = false
            self.closeDetailSelector(BtnConfigForDetail.sort)
            self.togglePkDateFormat = false
            self.closeDetailSelector(BtnConfigForDetail.dateFormat)
            self.toggleVTextAlign = false
            self.closeDetailSelector(BtnConfigForDetail.textAlign)
            self.toggleVContentsBackground = false
            self.closeDetailSelector(BtnConfigForDetail.contentsBackground)
            self.toggleVFilterColor = false
            self.closeDetailSelector(BtnConfigForDetail.filterColor)
            self.togglePkFontSize = true
            self.openDetailSelector(BtnConfigForDetail.fontSize)
        } else {
            self.togglePkFontSize = false
            self.closeDetailSelector(BtnConfigForDetail.fontSize)
        }
    }
    
    @IBAction func clickOpenTextAlign(_ sender: UIButton) {
        if self.toggleVTextAlign == false {
            self.togglePkSort = false
            self.closeDetailSelector(BtnConfigForDetail.sort)
            self.togglePkDateFormat = false
            self.closeDetailSelector(BtnConfigForDetail.dateFormat)
            self.togglePkFontSize = false
            self.closeDetailSelector(BtnConfigForDetail.fontSize)
            self.toggleVContentsBackground = false
            self.closeDetailSelector(BtnConfigForDetail.contentsBackground)
            self.toggleVFilterColor = false
            self.closeDetailSelector(BtnConfigForDetail.filterColor)
            self.toggleVTextAlign = true
            self.openDetailSelector(BtnConfigForDetail.textAlign)
        } else {
            self.toggleVTextAlign = false
            self.closeDetailSelector(BtnConfigForDetail.textAlign)
        }
    }

    @IBAction func clickBtnTextAlignLeft(_ sender: UIButton) {
        if checkTextAlign(!self.configController.config.textAlignLeft) {
            self.configController.config.textAlignLeft = !self.configController.config.textAlignLeft
            self.configController.updateConfig()
            self.setBtnTitleOpenTextAlign()
            self.setBtnTitleTextAlign()
        }
    }
    @IBAction func clickBtnTextAlignCenter(_ sender: UIButton) {
        if checkTextAlign(!self.configController.config.textAlignCenter) {
            self.configController.config.textAlignCenter = !self.configController.config.textAlignCenter
            self.configController.updateConfig()
            self.setBtnTitleOpenTextAlign()
            self.setBtnTitleTextAlign()
        }
    }
    @IBAction func clickBtnTextAlignRight(_ sender: UIButton) {
        if checkTextAlign(!self.configController.config.textAlignRight) {
            self.configController.config.textAlignRight = !self.configController.config.textAlignRight
            self.configController.updateConfig()
            self.setBtnTitleOpenTextAlign()
            self.setBtnTitleTextAlign()
        }
    }
    
    func checkTextAlign(_ changeValue: Bool) -> Bool {
        if changeValue == false {
            var result: Int = 0
            if self.configController.config.textAlignLeft {
                result = result + 1
            }
            if self.configController.config.textAlignCenter {
                result = result + 1
            }
            if self.configController.config.textAlignRight {
                result = result + 1
            }
            
            if result <= 1 {
                return false
            } else {
                return true
            }
        } else {
            return true
        }
    }
    
    func setBtnTitleOpenTextAlign() {
        let lsLeft = NSLocalizedString("Left", comment: "Left")
        let lsCenter = NSLocalizedString("Center", comment: "Center")
        let lsRight = NSLocalizedString("Right", comment: "Right")
        
        var result: String = ""
        if self.configController.config.textAlignLeft {
            result = lsLeft
        }
        if self.configController.config.textAlignCenter {
            if result == "" {
                result = lsCenter
            } else {
                result = result + ", " + lsCenter
            }
        }
        if self.configController.config.textAlignRight {
            if result == "" {
                result = lsRight
            } else {
                result = result + ", " + lsRight
            }
        }
        self.btnTextAlign.setTitle(result, for: UIControlState())
    }
    
    func setBtnTitleTextAlign() {
        var titleBtn: String
        
        if self.configController.config.textAlignLeft == true {
            titleBtn = "\u{f036}\u{f00c}"
        } else {
            titleBtn = "\u{f036}"
        }
        self.btnTextAlignLeft.setTitle(titleBtn, for: UIControlState())
        
        if self.configController.config.textAlignCenter == true {
            titleBtn = "\u{f037}\u{f00c}"
        } else {
            titleBtn = "\u{f037}"
        }
        self.btnTextAlignCenter.setTitle(titleBtn, for: UIControlState())
        
        if self.configController.config.textAlignRight == true {
            titleBtn = "\u{f038}\u{f00c}"
        } else {
            titleBtn = "\u{f038}"
        }
        self.btnTextAlignRight.setTitle(titleBtn, for: UIControlState())
    }

    @IBAction func clickOpenContentsBackground(_ sender: UIButton) {
        if self.toggleVContentsBackground == false {
            self.togglePkSort = false
            self.closeDetailSelector(BtnConfigForDetail.sort)
            self.togglePkDateFormat = false
            self.closeDetailSelector(BtnConfigForDetail.dateFormat)
            self.togglePkFontSize = false
            self.closeDetailSelector(BtnConfigForDetail.fontSize)
            self.toggleVFilterColor = false
            self.closeDetailSelector(BtnConfigForDetail.filterColor)
            self.toggleVTextAlign = false
            self.closeDetailSelector(BtnConfigForDetail.textAlign)
            self.toggleVContentsBackground = true
            self.openDetailSelector(BtnConfigForDetail.contentsBackground)
        } else {
            self.toggleVContentsBackground = false
            self.closeDetailSelector(BtnConfigForDetail.contentsBackground)
        }
    }
    
    @IBAction func clickBtnContentsBackgroundClear(_ sender: UIButton) {
        if checkContentsBackground(!self.configController.config.backgroundContentClear) {
            self.configController.config.backgroundContentClear = !self.configController.config.backgroundContentClear
            self.configController.updateConfig()
            self.setBtnTitleOpenContentsBackground()
            self.setBtnTitleContentsBackground()
        }
    }
    
    @IBAction func clickBtnContentsBackgroundBlack(_ sender: UIButton) {
        if checkContentsBackground(!self.configController.config.backgroundContentBlack) {
            self.configController.config.backgroundContentBlack = !self.configController.config.backgroundContentBlack
            self.configController.updateConfig()
            self.setBtnTitleOpenContentsBackground()
            self.setBtnTitleContentsBackground()
        }
    }

    func checkContentsBackground(_ changeValue: Bool) -> Bool {
        if changeValue == false {
            var result: Int = 0
            if self.configController.config.backgroundContentClear {
                result = result + 1
            }
            if self.configController.config.backgroundContentBlack {
                result = result + 1
            }
            
            if result <= 1 {
                return false
            } else {
                return true
            }
        } else {
            return true
        }
    }
    
    func setBtnTitleOpenContentsBackground() {
        let lsClear = NSLocalizedString("Clear", comment: "Clear")
        let lsBlack = NSLocalizedString("Black", comment: "Black")
        
        var result: String = ""
        if self.configController.config.backgroundContentClear {
            result = lsClear
        }
        if self.configController.config.backgroundContentBlack {
            if result == "" {
                result = lsBlack
            } else {
                result = result + ", " + lsBlack
            }
        }
        self.btnContentsBackground.setTitle(result, for: UIControlState())
    }
    
    func setBtnTitleContentsBackground() {
        var titleBtn: String
        
        if self.configController.config.backgroundContentClear == true {
            titleBtn = "\u{f05e}\u{f00c}"
        } else {
            titleBtn = "\u{f05e}"
        }
        self.btnContentsBackgroundClear.setTitle(titleBtn, for: UIControlState())
        
        if self.configController.config.backgroundContentBlack == true {
            titleBtn = "\u{f0c8}\u{f00c}"
        } else {
            titleBtn = "\u{f0c8}"
        }
        self.btnContentsBackgroundBlack.setTitle(titleBtn, for: UIControlState())
    }
    
    @IBAction func clickOpenFilterColor(_ sender: UIButton) {
        if self.toggleVFilterColor == false {
            self.togglePkSort = false
            self.closeDetailSelector(BtnConfigForDetail.sort)
            self.togglePkDateFormat = false
            self.closeDetailSelector(BtnConfigForDetail.dateFormat)
            self.togglePkFontSize = false
            self.closeDetailSelector(BtnConfigForDetail.fontSize)
            self.toggleVTextAlign = false
            self.closeDetailSelector(BtnConfigForDetail.textAlign)
            self.toggleVContentsBackground = false
            self.closeDetailSelector(BtnConfigForDetail.contentsBackground)
            self.toggleVFilterColor = true
            self.openDetailSelector(BtnConfigForDetail.filterColor)
        } else {
            self.toggleVFilterColor = false
            self.closeDetailSelector(BtnConfigForDetail.filterColor)
        }
    }
    
    @IBAction func clickBtnFilterColorClear(_ sender: UIButton) {
        if self.checkFilterColor(!self.configController.config.filterColorClear) {
            self.configController.config.filterColorClear = !self.configController.config.filterColorClear
            self.configController.updateConfig()
            self.setBtnTitleFilterColor()
        }
    }

    @IBAction func clickBtnFilterColorRed(_ sender: UIButton) {
        if self.checkFilterColor(!self.configController.config.filterColorRed) {
            self.configController.config.filterColorRed = !self.configController.config.filterColorRed
            self.configController.updateConfig()
            self.setBtnTitleFilterColor()
        }
    }
    
    @IBAction func clickBtnFilterColorOrange(_ sender: UIButton) {
        if self.checkFilterColor(!self.configController.config.filterColorOrange) {
            self.configController.config.filterColorOrange = !self.configController.config.filterColorOrange
            self.configController.updateConfig()
            self.setBtnTitleFilterColor()
        }
    }
    
    @IBAction func clickBtnFilterColorYellow(_ sender: UIButton) {
        if self.checkFilterColor(!self.configController.config.filterColorYellow) {
            self.configController.config.filterColorYellow = !self.configController.config.filterColorYellow
            self.configController.updateConfig()
            self.setBtnTitleFilterColor()
        }
    }
    
    @IBAction func clickBtnFilterColorGreen(_ sender: UIButton) {
        if self.checkFilterColor(!self.configController.config.filterColorGreen) {
            self.configController.config.filterColorGreen = !self.configController.config.filterColorGreen
            self.configController.updateConfig()
            self.setBtnTitleFilterColor()
        }
    }
    
    @IBAction func clickBtnFilterColorBlue(_ sender: UIButton) {
        if self.checkFilterColor(!self.configController.config.filterColorBlue) {
            self.configController.config.filterColorBlue = !self.configController.config.filterColorBlue
            self.configController.updateConfig()
            self.setBtnTitleFilterColor()
        }
    }
    
    @IBAction func clickBtnFilterColorIndigo(_ sender: UIButton) {
        if self.checkFilterColor(!self.configController.config.filterColorIndigo) {
            self.configController.config.filterColorIndigo = !self.configController.config.filterColorIndigo
            self.configController.updateConfig()
            self.setBtnTitleFilterColor()
        }
    }
    
    @IBAction func clickBtnFilterColorViolet(_ sender: UIButton) {
        if self.checkFilterColor(!self.configController.config.filterColorViolet) {
            self.configController.config.filterColorViolet = !self.configController.config.filterColorViolet
            self.configController.updateConfig()
            self.setBtnTitleFilterColor()
        }
    }
    
    @IBAction func clickBtnFilterColorWhite(_ sender: UIButton) {
        if self.checkFilterColor(!self.configController.config.filterColorWhite) {
            self.configController.config.filterColorWhite = !self.configController.config.filterColorWhite
            self.configController.updateConfig()
            self.setBtnTitleFilterColor()
        }
    }
    
    @IBAction func clickBtnFilterColorBlack(_ sender: UIButton) {
        if self.checkFilterColor(!self.configController.config.filterColorBlack) {
            self.configController.config.filterColorBlack = !self.configController.config.filterColorBlack
            self.configController.updateConfig()
            self.setBtnTitleFilterColor()
        }
    }

    func checkFilterColor(_ changeValue: Bool) -> Bool {
        if changeValue == false {
            var result: Int = 0
            if self.configController.config.filterColorClear {
                result = result + 1
            }
            if self.configController.config.filterColorRed {
                result = result + 1
            }
            if self.configController.config.filterColorOrange {
                result = result + 1
            }
            if self.configController.config.filterColorYellow {
                result = result + 1
            }
            if self.configController.config.filterColorGreen {
                result = result + 1
            }
            if self.configController.config.filterColorBlue {
                result = result + 1
            }
            if self.configController.config.filterColorIndigo {
                result = result + 1
            }
            if self.configController.config.filterColorViolet {
                result = result + 1
            }
            if self.configController.config.filterColorWhite {
                result = result + 1
            }
            if self.configController.config.filterColorBlack {
                result = result + 1
            }
            
            if result <= 1 {
                return false
            } else {
                return true
            }
        } else {
            return true
        }
    }
    
    func setBtnTitleFilterColor() {
        let btnFilterColorTitle: String = "\u{f0c8}"
        let btnChecker: String = "\u{f00c}"
        
        var titleBtn: String
        
        if self.configController.config.filterColorClear == true {
            titleBtn = "\u{f05e}" + btnChecker
        } else {
            titleBtn = "\u{f05e}"
        }
        self.btnFilterColorClear.setTitle(titleBtn,for: UIControlState())
        
        if self.configController.config.filterColorRed == true {
            titleBtn = btnFilterColorTitle + btnChecker
        } else {
            titleBtn = btnFilterColorTitle
        }
        self.btnFilterColorRed.setTitle(titleBtn,for: UIControlState())
        
        if self.configController.config.filterColorOrange == true {
            titleBtn = btnFilterColorTitle + btnChecker
        } else {
            titleBtn = btnFilterColorTitle
        }
        self.btnFilterColorOrange.setTitle(titleBtn,for: UIControlState())

        if self.configController.config.filterColorYellow == true {
            titleBtn = btnFilterColorTitle + btnChecker
        } else {
            titleBtn = btnFilterColorTitle
        }
        self.btnFilterColorYellow.setTitle(titleBtn,for: UIControlState())
        
        if self.configController.config.filterColorGreen == true {
            titleBtn = btnFilterColorTitle + btnChecker
        } else {
            titleBtn = btnFilterColorTitle
        }
        self.btnFilterColorGreen.setTitle(titleBtn,for: UIControlState())

        if self.configController.config.filterColorBlue == true {
            titleBtn = btnFilterColorTitle + btnChecker
        } else {
            titleBtn = btnFilterColorTitle
        }
        self.btnFilterColorBlue.setTitle(titleBtn,for: UIControlState())
        
        if self.configController.config.filterColorIndigo == true {
            titleBtn = btnFilterColorTitle + btnChecker
        } else {
            titleBtn = btnFilterColorTitle
        }
        self.btnFilterColorIndigo.setTitle(titleBtn,for: UIControlState())

        if self.configController.config.filterColorViolet == true {
            titleBtn = btnFilterColorTitle + btnChecker
        } else {
            titleBtn = btnFilterColorTitle
        }
        self.btnFilterColorViolet.setTitle(titleBtn,for: UIControlState())
        
        if self.configController.config.filterColorWhite == true {
            titleBtn = "\u{f096}" + btnChecker
        } else {
            titleBtn = "\u{f096}"
        }
        self.btnFilterColorWhite.setTitle(titleBtn,for: UIControlState())

        if self.configController.config.filterColorBlack == true {
            titleBtn = btnFilterColorTitle + btnChecker
        } else {
            titleBtn = btnFilterColorTitle
        }
        self.btnFilterColorBlack.setTitle(titleBtn,for: UIControlState())
    }
    
    func openDetailSelector(_ btn: BtnConfigForDetail) {
        if btn == BtnConfigForDetail.textAlign {
            self.vTextAlign.isHidden = false
        }
        if btn == BtnConfigForDetail.contentsBackground {
            self.vContentsBackground.isHidden = false
        }
        if btn == BtnConfigForDetail.filterColor {
            self.vFilterColorBtn.isHidden = false
        }

        if btn == BtnConfigForDetail.sort {
            self.constPkSortHeight.constant = self.heightPkSort
        }
        if btn == BtnConfigForDetail.dateFormat {
            self.constPkDateFormatHeight.constant = self.heightPkDateFormat
        }
        if btn == BtnConfigForDetail.fontSize {
            self.constPkFontSizeHeight.constant = self.heightPkFontSize
        }
        if btn == BtnConfigForDetail.textAlign {
            self.constBtnTextAlignHeight.constant = self.heightBtnTextAlign
        }
        if btn == BtnConfigForDetail.contentsBackground {
            self.constBtnContentsBackgroundHeight.constant = self.heightBtnContentsBackground
        }
        if btn == BtnConfigForDetail.filterColor {
            self.constBtnFilterColorClearHeight.constant = self.heightBtnFilterColor
        }
        
        UIView.animate(
            withDuration: 0.25,
            animations: {
                self.view.layoutIfNeeded()
        })
    }

    func closeDetailSelector(_ btn: BtnConfigForDetail) {
        if btn == BtnConfigForDetail.sort {
            self.constPkSortHeight.constant = 0
        }
        if btn == BtnConfigForDetail.dateFormat {
            self.constPkDateFormatHeight.constant = 0
        }
        if btn == BtnConfigForDetail.fontSize {
            self.constPkFontSizeHeight.constant = 0
        }
        if btn == BtnConfigForDetail.textAlign {
            self.constBtnTextAlignHeight.constant = 0
        }
        if btn == BtnConfigForDetail.contentsBackground {
            self.constBtnContentsBackgroundHeight.constant = 0
        }
        if btn == BtnConfigForDetail.filterColor {
            self.constBtnFilterColorClearHeight.constant = 0
        }

        UIView.animate(
            withDuration: 0.25,
            animations: {
                self.view.layoutIfNeeded()
            },
            completion: {
                _ in
                if btn == BtnConfigForDetail.textAlign {
                    self.vTextAlign.isHidden = true
                }
                if btn == BtnConfigForDetail.contentsBackground {
                    self.vContentsBackground.isHidden = true
                }
                if btn == BtnConfigForDetail.filterColor {
                    self.vFilterColorBtn.isHidden = true
                }
        })
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        if pickerView == self.pkFontSize {
            return 2
        }
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == self.pkSort {
            return self.pkSortDataSource.count
        }
        if pickerView == self.pkDateFormat {
            return self.pkDateFormatDataSource.count
        }
        return self.pkFontSizeDataSource[component].count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == self.pkSort {
            return self.pkSortDataSource[row]
        }
        if pickerView == self.pkDateFormat {
            return self.pkDateFormatDataSource[row]
        }
        return pkFontSizeDataSource[component][row]
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        var title = ""
        if pickerView == self.pkSort {
            title = self.pkSortDataSource[row]
        }
        if pickerView == self.pkDateFormat {
            title = self.pkDateFormatDataSource[row]
        }
        if pickerView == self.pkFontSize {
            title = pkFontSizeDataSource[component][row]
        }
        
        var pickerLabel = view as! UILabel!
        if view == nil {
            pickerLabel = UILabel()
            pickerLabel?.textAlignment = .center
            pickerLabel?.textColor = self.configController.config.codeColor5
            pickerLabel?.font.withSize(16)
        }
        pickerLabel?.text = title
        
        return pickerLabel!
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        if pickerView == self.pkSort {
            self.configController.config.sort = Int(row)
            self.setBtnTitleOpenPkSort()
        }
        if pickerView == self.pkDateFormat {
            let dateFormat = self.pkDateFormatDataSource[row]
            let newDateFormat = dateFormat.replacingOccurrences(of: "DD", with: "dd")
            self.configController.config.dateFormat = newDateFormat
            self.setBtnTitleOpenPkDateFormat()
        }
        if pickerView == self.pkFontSize {
            let fontSize: String = self.pkFontSizeDataSource[component][row]
            
            if component == 0 {
                self.configController.config.fontSizeMin = Int(fontSize)!
            }
            if component == 1 {
                self.configController.config.fontSizeMax = Int(fontSize)!
            }
            
            let min = Double(self.configController.config.fontSizeMin)
            let max = Double(self.configController.config.fontSizeMax)
            if min > max {
                if component == 0 {
                    self.configController.config.fontSizeMax = self.configController.config.fontSizeMin
                }
                if component == 1 {
                    self.configController.config.fontSizeMin = self.configController.config.fontSizeMax
                }
                self.setPkFontSize()
            }
            self.setBtnTitleOpenPkFontSize()
        }
        self.configController.updateConfig()
    }
    @IBAction func clickBtnBackup(_ sender: UIButton) {
        let lsBackupComplete = NSLocalizedString("Backup Complete", comment: "Backup Complete")
        let lsCheckIcloud = NSLocalizedString("Check iCloud", comment: "Check iCloud")
        let lsCheckIcloudMessage = NSLocalizedString("Check iCloud message", comment: "Check iCloud message")
        let lsCheckInternet = NSLocalizedString("Check internet", comment: "Check internet")
        let lsCheckInternetMessage = NSLocalizedString("Check internet message", comment: "Check internet message")
        
        if Reachability.isConnectedToNetwork() == true {
            let idocument = IDocument.sharedInstance
            if idocument.isCloudEnabled() {
                idocument.backupDocument()
                self.showAlert(lsBackupComplete)
            } else {
                self.alertMessage(lsCheckIcloud, message: lsCheckIcloudMessage)
            }
        } else {
            self.alertMessage(lsCheckInternet, message: lsCheckInternetMessage)
        }
    }
    @IBAction func clickBtnRestore(_ sender: UIButton) {
        let lsRestoreComplete = NSLocalizedString("Restore Complete", comment: "Restore Complete")
        let lsCheckIcloud = NSLocalizedString("Check iCloud", comment: "Check iCloud")
        let lsCheckIcloudMessage = NSLocalizedString("Check iCloud message", comment: "Check iCloud message")
        let lsCheckInternet = NSLocalizedString("Check internet", comment: "Check internet")
        let lsCheckInternetMessage = NSLocalizedString("Check internet message", comment: "Check internet message")
        
        if Reachability.isConnectedToNetwork() == true {
            let idocument = IDocument.sharedInstance
            if idocument.isCloudEnabled() {
                idocument.restoreDocument()
                self.showAlert(lsRestoreComplete)
            } else {
                self.alertMessage(lsCheckIcloud, message: lsCheckIcloudMessage)
            }
        } else {
            self.alertMessage(lsCheckInternet, message: lsCheckInternetMessage)
        }
    }

    func showAlert(_ message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: UIAlertControllerStyle.alert)
        self.present(alert, animated: true, completion: {(_) in} )
        
        let delay = 1.0 * Double(NSEC_PER_SEC)
        let time = DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: time, execute: {
            alert.dismiss(animated: true, completion: {(_) in})
        })
    }
    
    func alertMessage(_ title: String, message: String) {
        let lsOK = NSLocalizedString("OK", comment: "OK")
        let actionSheetController: UIAlertController = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        let cancelAction: UIAlertAction = UIAlertAction(title: lsOK, style: .cancel) { action -> Void in
        }
        actionSheetController.addAction(cancelAction)
        self.present(actionSheetController, animated: true, completion: nil)
    }
}
