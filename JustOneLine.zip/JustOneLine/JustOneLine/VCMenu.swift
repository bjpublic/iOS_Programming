//
//  VCSidebar.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 4..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit
import Firebase

class VCMenu: UIViewController {

    @IBOutlet var btnClose: UIButton!
    @IBOutlet var btnConfig: UIButton!
    @IBOutlet var btnHome: UIButton!
    @IBOutlet var btnContactUs: UIButton!
    @IBOutlet var btnWriteReview: UIButton!
    @IBOutlet var btnFacebook: UIButton!
    @IBOutlet var btnMonorial: UIButton!
    @IBOutlet var lblVersion: UILabel!
    @IBOutlet var vTransparent: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setInit()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func setInit() {
        self.btnClose.setTitle("\u{f00d}",for: UIControlState())
        self.btnConfig.setTitle("\u{f013}",for: UIControlState())
        self.btnHome.setTitle("\u{f015}",for: UIControlState())
        self.btnContactUs.setTitle("\u{f0e0}",for: UIControlState())
        self.btnWriteReview.setTitle("\u{f075}",for: UIControlState())
        self.btnFacebook.setTitle("\u{f082}",for: UIControlState())

        self.btnMonorial.layer.cornerRadius = 4
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(VCMenu.closeView))
        self.vTransparent.addGestureRecognizer(tap)
        
        if let version = Bundle.main.infoDictionary?["CFBundleVersion"] as? String {
            self.lblVersion.text = "Version \(version)"
        }
    }
    
    @IBAction func closeMenu(_ sender: UIButton) {
        self.closeView()
    }
    
    func closeView() {
        UIView.animate(
            withDuration: 0.25,
            delay: 0.0,
            options: UIViewAnimationOptions.curveEaseOut,
            animations: {
                self.view.transform = CGAffineTransform(translationX: -self.view.frame.size.width, y: 0)
            },
            completion: { finished in
                self.presentingViewController?.dismiss(animated: true, completion: nil)
            }
        )
    }
    
    @IBAction func clickConfig(_ sender: UIButton) {
        self.presentingViewController?.dismiss(animated: false, completion: nil)
        if let uvc = self.storyboard?.instantiateViewController(withIdentifier: "VCConfig") as? VCConfig {
            uvc.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
            uvc.modalPresentationStyle = .overCurrentContext
            self.presentingViewController?.present(uvc, animated: true, completion: nil)
        }
    }
    
    @IBAction func clickAbout(_ sender: UIButton) {
        if let eedlerHome = URL(string: "http://www.eedler.com/") {
            UIApplication.shared.openURL(eedlerHome)
        }
    }
    
    @IBAction func clickContactUs(_ sender: UIButton) {
        if let emailURL = URL(string: "mailto:justoneline@eedler.com") {
            UIApplication.shared.openURL(emailURL)
        }
    }
    
    @IBAction func clickWriteReview(_ sender: UIButton) {
        let idApp: String = "1123889307"
        if let appStoreURL = URL(string: "https://itunes.apple.com/en/app/id" + idApp) {
            UIApplication.shared.openURL(appStoreURL)
        }
    }
    
    @IBAction func clickFacebook(_ sender: UIButton) {
        if let fbURL = URL(string: "https://www.facebook.com/eedler.co") {
            UIApplication.shared.openURL(fbURL)
        }
    }
    
    @IBAction func openMonorial(_ sender: UIButton) {
        FIRAnalytics.logEvent(withName: "open_monorial_in_menu", parameters: nil)
        let idApp: String = "1146274990"
        if let appStoreURL = URL(string: "https://itunes.apple.com/en/app/id" + idApp) {
            UIApplication.shared.openURL(appStoreURL)
        }
    }
}
