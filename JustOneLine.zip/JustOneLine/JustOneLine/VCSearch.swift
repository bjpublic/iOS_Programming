//
//  VCSearch.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 23..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit
import CoreData

class VCSearch: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var btnClose: UIButton!
    @IBOutlet var txtSearch: UITextField!
    @IBOutlet var tblView: UITableView!
    
    var lineController = LineController.sharedInstance
    let configController = ConfigController.sharedInstance
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setInit()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    func setInit() {
        self.txtSearch.delegate = self
        self.tblView.tableFooterView = UIView(frame:CGRect.zero)
        self.tblView.separatorColor = UIColor.white
        self.txtSearch.addTarget(self, action: #selector(VCSearch.txtSearchDidChange(_:)), for: UIControlEvents.editingChanged)
        
        self.lineController.initData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.txtSearch.becomeFirstResponder()
    }
    
    @IBAction func closeSearch(_ sender: UIButton) {
        self.closeView()
    }
    
    func closeView() {
        self.lineController.setAllData()
        let vc = self.presentingViewController as! ViewController
        vc.tblView.reloadData()
        vc.dismiss(animated: true, completion: nil)
    }

    func txtSearchDidChange(_ textField: UITextField) {
        if (textField == self.txtSearch) {
            self.refreshData()
        }
    }

    func refreshData() {
        self.lineController.searchData(self.txtSearch.text!)
        self.tblView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.lineController.lineContainers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = self.lineController.lineContainers[(indexPath as NSIndexPath).row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchCell") as! SearchCell
        
        cell.backgroundColor = UIColor.clear
        cell.lblContent.text? = row.line.content
        cell.lblCreatedAt.text? = self.configController.getDateTimeFormat(row.line.createdAt)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let row = self.lineController.lineContainers[(indexPath as NSIndexPath).row]
        self.openShow(row.idx)
    }
    
    func openShow(_ idx: Int) {
        if let uvc = self.storyboard?.instantiateViewController(withIdentifier: "PVCShow") as? PVCShow {
            uvc.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
            uvc.modalPresentationStyle = .overCurrentContext
            uvc.idx = idx
            self.present(uvc, animated: true, completion: nil)
        }
    }
}
