//
//  VCShow.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 5..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit
import Social

class VCShow: UIViewController {
    
    @IBOutlet var imgBg: UIImageView!
    
    @IBOutlet var vFilter: UIView!
    @IBOutlet var vContent: UIView!
    @IBOutlet var lblContent: UILabel!
    @IBOutlet var lblSubContent: UILabel!
    @IBOutlet var constTopVContent: NSLayoutConstraint!
    @IBOutlet var constTopContent: NSLayoutConstraint!
    @IBOutlet var constGapContentSubContent: NSLayoutConstraint!
    
    @IBOutlet var vUi: UIView!
    @IBOutlet var btnClose: UIButton!
    @IBOutlet var btnBack: UIButton!
    @IBOutlet var btnNext: UIButton!
    @IBOutlet var btnFacebook: UIButton!
    @IBOutlet var btnTwitter: UIButton!
    @IBOutlet var btnRefresh: UIButton!
    @IBOutlet var btnDownload: UIButton!
    @IBOutlet var btnEdit: UIButton!
    @IBOutlet var btnDelete: UIButton!
    @IBOutlet var lblCreatedAt: UILabel!
    
    let configController = ConfigController.sharedInstance
    
    var boxView = UIView()
    let lineController = LineController.sharedInstance
    var lineContainer = LineContainer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setInit()
        self.setContent()
        self.setBtnColor()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let pvc = self.parent as! PVCShow
        pvc.idx = self.lineContainer.idx

        let nowIndex = lineController.getIndex(self.lineContainer.idx)
        let maxIndex = lineController.lineContainers.count-1
        
        if nowIndex == 0 {
            self.btnBack.setTitleColor(UIColor.gray, for: UIControlState())
        } else {
            self.btnBack.setTitleColor(self.btnRefresh.currentTitleColor, for: UIControlState())
        }

        if nowIndex == maxIndex {
            self.btnNext.setTitleColor(UIColor.gray, for: UIControlState())
        } else {
            self.btnNext.setTitleColor(self.btnRefresh.currentTitleColor, for: UIControlState())
        }
        
        if configController.config.activeBtnInShow == true {
            self.vUi.isHidden = false
        } else {
            self.vUi.isHidden = true
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
            self.vUi.isHidden = true
    }
    
    func setInit() {
        self.btnClose.setTitle("\u{f00d}",for: UIControlState())
        self.btnBack.setTitle("\u{f04a}", for: UIControlState())
        self.btnNext.setTitle("\u{f04e}", for: UIControlState())
        self.btnFacebook.setTitle("\u{f09a}", for: UIControlState())
        self.btnTwitter.setTitle("\u{f099}", for: UIControlState())
        self.btnRefresh.setTitle("\u{f021}", for: UIControlState())
        self.btnDownload.setTitle("\u{f019}", for: UIControlState())
        self.btnEdit.setTitle("\u{f044}", for: UIControlState())
        self.btnDelete.setTitle("\u{f014}", for: UIControlState())
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(VCShow.hideBtn))
        self.vUi.addGestureRecognizer(tap)
        let tap1 = UITapGestureRecognizer(target: self, action: #selector(VCShow.activeBtn))
        self.vFilter.addGestureRecognizer(tap1)
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(VCShow.setRandom))
        swipeDown.direction = .down
        self.vFilter.addGestureRecognizer(swipeDown)
        
        self.vUi.isHidden = true
    }

    func setContent() {
        self.lblContent.text = self.lineContainer.line.content
        self.lblSubContent.text = self.lineContainer.line.subContent
        self.lblCreatedAt.text = configController.getDateTimeFormat(self.lineContainer.line.createdAt)
        
        self.imgBg.image = self.lineContainer.imgBg
        self.vFilter.backgroundColor = self.lineContainer.filterColor
        self.vContent.backgroundColor = self.lineContainer.vContentBackgroundColor
        
        let fontSize = self.lineContainer.fontSize
        self.lblContent.font = self.lblContent.font.withSize(fontSize)
        self.lblSubContent.font = self.lblSubContent.font.withSize(fontSize - 4)
        
        self.lblContent.textAlignment = self.lineContainer.fontAlign
        self.lblSubContent.textAlignment = self.lineContainer.fontAlign
        
        if self.lblSubContent.text == "" {
            self.constGapContentSubContent.constant = 0
        } else {
            self.constGapContentSubContent.constant = 4
        }
        
        if self.lineContainer.constTopVContent == 0 {
            //let heightContents: CGFloat = self.vContent.frame.height
            let heightContents: CGFloat = 30 + self.lblContent.requiredHeight() + self.constGapContentSubContent.constant + self.lblSubContent.requiredHeight()
            
            let ltdRnd = LimitedRandom.sharedInstance
            let constTopVContent = ltdRnd.getRandomConstContent(heightContents)
            self.lineContainer.constTopVContent = constTopVContent
        }
        self.constTopVContent.constant = self.lineContainer.constTopVContent
    }
    
    func setRandom() {
        let ltdRnd = LimitedRandom.sharedInstance
        self.lineContainer.imgBg = ltdRnd.getRandomImage()
        self.lineContainer.filterColor = ltdRnd.getRandomFilterColor()
        self.lineContainer.vContentBackgroundColor = ltdRnd.getRandomVContentBgColor()
        self.lineContainer.fontSize = ltdRnd.getRandomFontSize()
        self.lineContainer.fontAlign = ltdRnd.getRandomAlign()
        self.lineContainer.constTopVContent = 0
        
        self.setContent()
    }
    
    func setBtnColor() {
        let color = self.configController.config.codeColor444
        self.btnClose.setTitleColor(color, for: UIControlState())
        self.btnBack.setTitleColor(color, for: UIControlState())
        self.btnNext.setTitleColor(color, for: UIControlState())
        self.btnFacebook.setTitleColor(color, for: UIControlState())
        self.btnTwitter.setTitleColor(color, for: UIControlState())
        self.btnRefresh.setTitleColor(color, for: UIControlState())
        self.btnDownload.setTitleColor(color, for: UIControlState())
        self.btnEdit.setTitleColor(color, for: UIControlState())
        self.btnDelete.setTitleColor(color, for: UIControlState())
    }
    
    func hideBtn() {
        self.vUi.isHidden = true
        configController.setActiveBtnInShow(false)
    }
    
    func activeBtn() {
        self.vUi.isHidden = false
        configController.setActiveBtnInShow(true)
    }

    @IBAction func clickBtnClose(_ sender: UIButton) {
        self.closeVCShow()
    }
    
    func closeVCShow() {
        if let vc = self.presentingViewController as? ViewController {
            vc.refreshData()
        }
        if let svc = self.presentingViewController as? VCSearch {
            svc.refreshData()
        }
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func clickBtnBack(_ sender: UIButton) {
        let pvc = self.parent as! PVCShow
        pvc.moveBack()
    }
    
    @IBAction func clickBtnNext(_ sender: UIButton) {
        let pvc = self.parent as! PVCShow
        pvc.moveNext()
    }
    
    @IBAction func clickBtnRefresh(_ sender: UIButton) {
        self.setRandom()
    }
    
    @IBAction func clickBtnDownload(_ sender: UIButton) {
        self.btnDownload.isEnabled = false
        self.saveScreenShot()
        self.showAlert("The photo was saved")
        self.btnDownload.isEnabled = true
    }
    
    @IBAction func clickEdit(_ sender: UIButton) {
        if let uvc = self.storyboard?.instantiateViewController(withIdentifier: "VCWrite") as? VCWrite {
            uvc.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
            uvc.modalPresentationStyle = .overCurrentContext
            uvc.writeType = WriteType.update
            uvc.lineContainer = self.lineContainer
            self.present(uvc, animated: true, completion: nil)
        }
    }
    
    @IBAction func clickDelete(_ sender: UIButton) {
        self.deleteLine()
    }
    
    func deleteLine() {
        let actionSheetController: UIAlertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        let cancelAction: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel) { action -> Void in
        }
        actionSheetController.addAction(cancelAction)
        let actDelete: UIAlertAction = UIAlertAction(title: "Delete", style: .default) { action -> Void in
            let lineController = LineController.sharedInstance
            let index = self.lineController.getIndex(self.lineContainer.idx)
            lineController.deleteLineByIdx(self.lineContainer)
            
            if lineController.lineContainers.count == 0 {
                self.closeVCShow()
            } else {
                let pvc = self.parent as! PVCShow
                pvc.refresh()

                if index <= lineController.lineContainers.count - 1 {
                    pvc.moveToIndex(index)
                } else {
                    pvc.moveToIndex(lineController.lineContainers.count-1)
                }
            }
        }
        actionSheetController.addAction(actDelete)
        self.present(actionSheetController, animated: true, completion: nil)
    }
    
    @IBAction func clickFacebook(_ sender: UIButton) {
        if SLComposeViewController.isAvailable(forServiceType: SLServiceTypeFacebook){
            let screenshot = self.getScreenShot()
            let facebookSheet:SLComposeViewController = SLComposeViewController(forServiceType: SLServiceTypeFacebook)
            let initialText = "#justoneline"
            facebookSheet.setInitialText(initialText)
            facebookSheet.add(screenshot)
            self.present(facebookSheet, animated: true, completion: nil)
        } else {
            let lsChkFb = NSLocalizedString("Check Facebook", comment: "Check Facebook")
            let lsOK = NSLocalizedString("OK", comment: "OK")
            let alert = UIAlertController(title: "Accounts", message: lsChkFb, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: lsOK, style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func clickTwitter(_ sender: UIButton) {
        if SLComposeViewController.isAvailable(forServiceType: SLServiceTypeTwitter){
            let screenshot = self.getScreenShot()
            let twitterSheet:SLComposeViewController = SLComposeViewController(forServiceType: SLServiceTypeTwitter)
            let initialText = "#justoneline"
            twitterSheet.setInitialText(initialText)
            twitterSheet.add(screenshot)
            self.present(twitterSheet, animated: true, completion: nil)
        } else {
            let lsChkTwitter = NSLocalizedString("Check Twitter", comment: "Check Twitter")
            let lsOK = NSLocalizedString("OK", comment: "OK")
            let alert = UIAlertController(title: "Accounts", message: lsChkTwitter, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: lsOK, style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }

    func getScreenShot() -> UIImage {
        self.vUi.isHidden = true
        let layer = UIApplication.shared.keyWindow!.layer
        let scale = UIScreen.main.scale
        UIGraphicsBeginImageContextWithOptions(layer.frame.size, false, scale);
        layer.render(in: UIGraphicsGetCurrentContext()!)
        let screenshot = UIGraphicsGetImageFromCurrentImageContext()
        self.vUi.isHidden = false
        
        return screenshot!
    }
    
    func saveScreenShot() {
        let screenshot = self.getScreenShot()
        UIGraphicsEndImageContext()
        UIImageWriteToSavedPhotosAlbum(screenshot, nil, nil, nil)
    }
    
    func showAlert(_ message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: UIAlertControllerStyle.alert)
        self.present(alert, animated: true, completion: {(_) in} )
        
        let delay = 1.0 * Double(NSEC_PER_SEC)
        let time = DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)
        DispatchQueue.main.asyncAfter(deadline: time, execute: {
            alert.dismiss(animated: true, completion: {(_) in})
        })
    }
    
    /*
    func colorizeImage(image : UIImage, tintColor : UIColor) -> UIImage? {
        let colorMatrixFilter = CIFilter(name: "CIColorMatrix")!
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        tintColor.getRed(&r, green:&g, blue:&b, alpha:&a)
        colorMatrixFilter.setDefaults()
        colorMatrixFilter.setValue(CIImage(image: image)!, forKey:"inputImage")
        colorMatrixFilter.setValue(CIVector(x:r, y:0, z:0, w:0), forKey:"inputRVector")
        colorMatrixFilter.setValue(CIVector(x:0, y:g, z:0, w:0), forKey:"inputGVector")
        colorMatrixFilter.setValue(CIVector(x:0, y:0, z:b, w:0), forKey:"inputBVector")
        colorMatrixFilter.setValue(CIVector(x:0, y:0, z:0, w:a), forKey:"inputAVector")
        if let ciimage = colorMatrixFilter.outputImage {
            return UIImage(CIImage: ciimage)
        }
        return nil
    } */
}

extension UILabel{
    func requiredHeight() -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: self.frame.width, height: CGFloat.greatestFiniteMagnitude))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = self.font
        label.text = self.text
        label.sizeToFit()
        return label.frame.height
    }
}
