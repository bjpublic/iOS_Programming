//
//  VCWrite.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 5. 2..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit

class VCWrite: UIViewController, UITextViewDelegate, UITextFieldDelegate {
    
    @IBOutlet var btnClose: UIButton!
    @IBOutlet var txtContent: UITextView!
    @IBOutlet var lblPlaceHolder: UILabel!
    @IBOutlet var txtSubContent: UITextField!
    @IBOutlet var btnWrite: UIButton!
    
    @IBOutlet var vAC: UIView!
    @IBOutlet var lblAC: UILabel!
    
    @IBOutlet var btnDateAC: UIButton!
    @IBOutlet var btnTimeAC: UIButton!
    
    let maxLengthContent: Int = 200
    let maxLengthSubContent: Int = 100
    var nowLengthContent: Int = 0
    var nowLengthSubContent: Int = 0
    
    var newIdx: Int = 0
    
    var lineContainer = LineContainer()
    var writeType = WriteType.insert
    
    let config = Config.sharedInstance
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtContent.delegate = self
        self.txtSubContent.delegate = self
        
        self.setInit()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.txtContent.becomeFirstResponder()
    }
    
    func setInit() {
        self.btnClose.setTitle("\u{f00d}", for: UIControlState())
        self.btnDateAC.setTitle("\u{f133}", for: UIControlState())
        self.btnTimeAC.setTitle("\u{f017}", for: UIControlState())
        self.txtContent.inputAccessoryView = self.vAC
        self.txtSubContent.inputAccessoryView = self.vAC
        
        self.changeBgColor()
        
        if self.writeType == .update {
            self.btnWrite.setTitle("Change",for: UIControlState())
            self.txtContent.text = self.lineContainer.line.content
            self.txtSubContent.text = self.lineContainer.line.subContent
        }
        
        if self.txtContent.text.isEmpty {
            self.lblPlaceHolder.isHidden = false;
        } else {
            self.lblPlaceHolder.isHidden = true;
        }
        self.setLengthContent()
        self.setLengthSubContent()
    }
    
    func changeBgColor() {
        //self.btnWrite.setTitleColor(config.codeColor5,forState: .Normal)
        //self.view.backgroundColor = config.codeColor5
    }

    @IBAction func clickBtnClose(_ sender: UIButton) {
        self.closeWrite()
    }
    
    func closeWrite() {
        /*if self.writeType == .insert {
            let vc = self.presentingViewController as! ViewController
            vc.dismiss(animated: true, completion: nil)
        }
        if self.writeType == .update {
            let pvc = self.presentingViewController as! PVCShow
            pvc.dismiss(animated: true, completion: nil)
        }*/
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func writeContent(_ sender: UIButton) {
        if self.writeType == .insert {
            if self.insertLine() {
                let vc = self.presentingViewController as! ViewController
                vc.refreshData()
                self.closeWrite()
                
                if self.newIdx != 0 {
                    vc.openShow(self.newIdx)
                }
            }
        }
        if self.writeType == .update {
            if self.updateLine() {
                let lineController = LineController.sharedInstance
                let index = lineController.getIndex(self.lineContainer.idx)
                
                let pvc = self.presentingViewController as! PVCShow
                pvc.refresh()
                pvc.moveToIndex(index, animated: false)
                
                self.closeWrite()
            }
        }
    }
    
    func insertLine() -> Bool {
        if self.chkSubmit() {
            let line = Line()
            line.content = self.txtContent.text
            line.subContent = self.txtSubContent.text!
            
            let lineController = LineController.sharedInstance
            self.newIdx = lineController.insertLine(line)
            return true
        } else {
            return false
        }
    }
    
    func updateLine() -> Bool {
        if self.chkSubmit() {
            self.lineContainer.line.content = self.txtContent.text
            self.lineContainer.line.subContent = self.txtSubContent.text!
            
            let lineController = LineController.sharedInstance
            lineController.updateLine(self.lineContainer)            
            return true
        } else {
            return false
        }
    }

    func chkSubmit() -> Bool {
        guard self.nowLengthContent > 0 else {
            self.txtContent.becomeFirstResponder()
            return false
        }
        guard self.nowLengthContent <= self.maxLengthContent else {
            self.txtContent.becomeFirstResponder()
            return false
        }
        guard self.nowLengthSubContent <= self.maxLengthSubContent else {
            self.txtSubContent.becomeFirstResponder()
            return false
        }
        return true
    }
    
    // implemented UITextView Delegate
    func textViewDidBeginEditing(_ textView: UITextView) {
        if (textView == self.txtContent) {
            self.setLengthContent()
        }
    }
    func textViewDidChange(_ textView: UITextView) {
        if (textView == self.txtContent) {
            self.setLengthContent()
            
            if textView.text.isEmpty {
                self.lblPlaceHolder.isHidden = false;
            } else {
                self.lblPlaceHolder.isHidden = true;
            }
        }
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if (textView == self.txtContent) {
            if (text == "\n") {
                textView.resignFirstResponder()
                self.txtSubContent.becomeFirstResponder()
            }
        }
        return true
    }
    
    // implemented UITextField Delegate
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if (textField == self.txtSubContent) {
            self.setLengthSubContent()
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if (textField == self.txtSubContent) {
            let textLength = textField.text?.utf16.count
            let length = textLength! + string.utf16.count - range.length
            self.setLengthLblAC(length, maxLength: self.maxLengthSubContent)
            self.nowLengthSubContent = length
        }
        return true
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    //accessoryView
    
    @IBAction func dismissKeyboard(_ sender: UIButton) {
        self.txtContent.resignFirstResponder()
        self.txtSubContent.resignFirstResponder()
    }
    
    func setLengthContent() {
        let length = self.txtContent.text.characters.count
        self.setLengthLblAC(length, maxLength: self.maxLengthContent)
        self.nowLengthContent = length
    }
    func setLengthSubContent() {
        let length = self.txtSubContent.text!.characters.count
        self.setLengthLblAC(length, maxLength: self.maxLengthSubContent)
        self.nowLengthSubContent = length
    }
    
    func setLengthLblAC(_ length: Int, maxLength: Int) {
        self.lblAC.text = "\(length) / \(maxLength)"
        if length > maxLength {
            self.lblAC.textColor = UIColor(red: 176.0/255.0, green:70.0/255.0, blue: 50.0/255.0, alpha: 1.0)
        } else {
            self.lblAC.textColor = UIColor.white
        }
    }
    
    @IBAction func insertDate(_ sender: UIButton) {
        let now = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = self.config.dateFormat
        let nowDate = formatter.string(from: now)
        
        if self.txtContent.isFirstResponder == true {
            self.txtContent.insertText(nowDate)
            self.setLengthContent()
        }
        if self.txtSubContent.isFirstResponder == true {
            self.txtSubContent.insertText(nowDate)
            self.setLengthSubContent()
        }
    }
    
    @IBAction func insertTime(_ sender: UIButton) {
        let now = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        let nowTime = formatter.string(from: now)
        
        if self.txtContent.isFirstResponder == true {
            self.txtContent.insertText(nowTime)
            self.setLengthContent()
        }
        if self.txtSubContent.isFirstResponder == true {
            self.txtSubContent.insertText(nowTime)
            self.setLengthSubContent()
        }
    }
}
