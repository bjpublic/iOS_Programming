//
//  ViewController.swift
//  JustOneLine
//
//  Created by yongho Yu on 2016. 4. 26..
//  Copyright © 2016년 eedler. All rights reserved.
//

import UIKit
import CoreData
import Firebase

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var btnSearch: UIButton!
    @IBOutlet var btnMenu: UIButton!
    @IBOutlet var btnClock: UIButton!
    @IBOutlet var btnWrite: UIButton!
    @IBOutlet var tblView: UITableView!
    @IBOutlet var lblIntro: UILabel!
    
    var timer = Timer()
    let configController = ConfigController.sharedInstance
    let lineController = LineController.sharedInstance
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.setInit()
        self.refreshData()
        if self.configController.config.sort == 1 {
            self.moveScroll(.bottom)
        }
        /*
        for lineContainer in self.lineController.lineContainers {
            print("\(lineContainer.line.content) / \(lineContainer.line.subContent) / \(lineContainer.line.createdAt)")
        }*/
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.timer.invalidate()
        self.timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.setClock), userInfo: nil, repeats: true)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.timer.invalidate()
    }
    
    func setInit() {
        self.btnMenu.setTitle("\u{f0c9}", for: UIControlState())
        self.btnSearch.setTitle("\u{f002}", for: UIControlState())
        self.btnWrite.setTitle("\u{f14b}", for: UIControlState())

        self.setClock()
        self.tblView.tableFooterView = UIView(frame:CGRect.zero)
    }
    
    func refreshData() {
        self.tblView.reloadData()
        if self.lineController.lineContainers.count > 0 {
            self.lblIntro.isHidden = true
        } else {
            self.lblIntro.isHidden = false
        }
    }
    
    func setClock() {
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        let nowTime = formatter.string(from: date)
        self.btnClock.setTitle(nowTime, for: UIControlState())
    }
    
    func moveScroll(_ direction: Direction) {
        if direction == Direction.top {
            self.tblView.setContentOffset(CGPoint.zero, animated: true)
        }
        
        if direction == Direction.bottom {
            let tblHeight = self.tblView.contentSize.height - self.tblView.bounds.size.height
            if tblHeight > 0 {
                let bottomPoint: CGPoint = CGPoint(x: 0, y: tblHeight)
                self.tblView.setContentOffset(bottomPoint, animated: true)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return self.lines.count
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.lineController.lineContainers.count
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = self.lineController.lineContainers[(indexPath as NSIndexPath).section]
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell") as! LineCell
        
        cell.layer.borderWidth = 1.0
        cell.layer.borderColor = UIColor.clear.cgColor
        cell.layer.cornerRadius = 3.0
        cell.backgroundColor = UIColor.clear
        
        cell.lblContent.text? = row.line.content
        cell.imgView.image = row.imgBg
        cell.lblCreatedAt.text? = self.configController.getDateTimeFormat(row.line.createdAt)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let row = self.lineController.lineContainers[(indexPath as NSIndexPath).section]
        self.openShow(row.idx)
    }
    
    func openShow(_ idx: Int) {
        if let uvc = self.storyboard?.instantiateViewController(withIdentifier: "PVCShow") as? PVCShow {
            uvc.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
            uvc.modalPresentationStyle = .overCurrentContext
            uvc.idx = idx
            self.present(uvc, animated: true, completion: nil)
        }
    }

    @IBAction func clickBtnClock(_ sender: UIButton) {
        self.moveScroll(.top)
    }
    
    @IBAction func openSearch(_ sender: UIButton) {
        if let uvc = self.storyboard?.instantiateViewController(withIdentifier: "VCSearch") as? VCSearch {
            uvc.modalTransitionStyle = UIModalTransitionStyle.coverVertical
            uvc.modalPresentationStyle = .overCurrentContext
            self.present(uvc, animated: true, completion: nil)
        }
    }
    
    @IBAction func openMenu(_ sender: UIButton) {
        if let uvc = self.storyboard?.instantiateViewController(withIdentifier: "VCMenu") as? VCMenu {
            uvc.modalPresentationStyle = .overCurrentContext
            self.view.superview?.insertSubview(uvc.view, aboveSubview: self.view)
            uvc.view.transform = CGAffineTransform(translationX: -self.view.frame.size.width, y: 0)
            UIView.animate(
                withDuration: 0.25,
                delay: 0.0,
                options: UIViewAnimationOptions(),
                animations: {
                    uvc.view.transform = CGAffineTransform(translationX: 0, y: 0)
                },
                completion: { finished in
                    self.present(uvc, animated: false, completion: nil)
                }
            )
        }
    }
    
    @IBAction func openWrite(_ sender: UIButton) {
        if let uvc = self.storyboard?.instantiateViewController(withIdentifier: "VCWrite") as? VCWrite {
            uvc.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
            uvc.modalPresentationStyle = .overCurrentContext
            self.present(uvc, animated: true, completion: nil)
        }
    }
    
    @IBAction func clickBtnScrollDown(_ sender: UIButton) {
        self.moveScroll(.bottom)
    }
}
